// =====================================================================
// Nón Lá – Vietnamese Folk Games hub
// Core: GameRegistry + LanguageManager + SaveManager + UI (menu, end panel, suggestions)
// Each game file calls Core.register({ id, icon, name, tag, rules, mount(root, api) }).
// =====================================================================
const Core = (() => {
  // ---------- SaveManager (localStorage, safe) ----------
  const store = {
    get(k, d = null) { try { const v = localStorage.getItem('nonla_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('nonla_' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  };

  // ---------- LanguageManager ----------
  let LANG = store.get('lang', (navigator.language || 'en').toLowerCase().startsWith('vi') ? 'vi' : 'en');
  const t = (vi, en) => (LANG === 'vi' ? vi : en);
  const other = () => (LANG === 'vi' ? 'en' : 'vi');

  // ---------- GameRegistry ----------
  const games = [];
  const register = g => games.push(g);
  const byId = id => games.find(g => g.id === id);

  let current = null, session = null;
  const $ = s => document.querySelector(s);

  function played() { return store.get('played', []); }
  function markPlayed(id) { const p = played(); if (!p.includes(id)) { p.push(id); store.set('played', p); } }

  function fmtBest(g, v) { return g.fmtBest ? g.fmtBest(v, t) : v; }

  // ---------- Session API given to each game ----------
  function makeSession(game, root) {
    const s = { alive: true, rafs: new Set(), timers: new Set(), listeners: [] };
    const api = {
      t, lang: () => LANG,
      alive: () => s.alive,
      sleep: ms => new Promise(r => { const id = setTimeout(r, ms); s.timers.add(id); }),
      timeout(fn, ms) { const id = setTimeout(() => { s.timers.delete(id); if (s.alive) fn(); }, ms); s.timers.add(id); return id; },
      interval(fn, ms) { const id = setInterval(() => { if (s.alive) fn(); }, ms); s.timers.add(id); return id; },
      clear(id) { clearTimeout(id); clearInterval(id); s.timers.delete(id); },
      on(target, ev, fn, opt) { target.addEventListener(ev, fn, opt); s.listeners.push([target, ev, fn, opt]); },
      loop(fn) {
        const h = { stopped: false }; let last = performance.now();
        const tick = now => {
          if (!s.alive || h.stopped) return;
          const dt = Math.min(0.05, (now - last) / 1000); last = now;
          if (fn(dt, now) === false) { h.stopped = true; return; }
          h.id = requestAnimationFrame(tick);
        };
        h.id = requestAnimationFrame(tick); s.rafs.add(h);
        return () => { h.stopped = true; cancelAnimationFrame(h.id); };
      },
      canvas(parent, aspect = 0.75) {
        const cv = document.createElement('canvas'); cv.className = 'game-canvas'; parent.appendChild(cv);
        const W = Math.min(parent.clientWidth || 360, 640), H = Math.round(W * aspect);
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        cv.width = W * dpr; cv.height = H * dpr; cv.style.aspectRatio = `${W} / ${H}`;
        const ctx = cv.getContext('2d'); ctx.scale(dpr, dpr);
        const pos = e => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * W / r.width, y: (e.clientY - r.top) * H / r.height }; };
        return { cv, ctx, W, H, pos };
      },
      best: () => store.get('best_' + game.id),
      // ---- Levels: increasing difficulty, unlocked one by one ----
      // levelBar(container, max, onChange): renders "Level 1 2 3 …" buttons (locked ones show 🔒).
      levelBar(container, max, onChange) {
        s.level = { max, onChange, cur: Math.min(store.get('lvl_' + game.id, 1), max) };
        const el = document.createElement('div'); el.className = 'lvl-bar'; container.prepend(el);
        s.level.el = el;
        const draw = () => {
          const un = store.get('lvl_' + game.id, 1);
          el.innerHTML = `<span>${t('Cấp độ', 'Level')}</span>` + Array.from({ length: max }, (_, i) => i + 1).map(n =>
            `<button data-n="${n}" class="${n === s.level.cur ? 'active' : ''}" ${n > un ? 'disabled' : ''}>${n > un ? '🔒' : n}</button>`).join('');
          el.querySelectorAll('button').forEach(b => b.onclick = () => { s.level.cur = +b.dataset.n; draw(); onChange(s.level.cur); });
        };
        s.level.draw = draw; draw();
        return s.level.cur;
      },
      level: () => (s.level ? s.level.cur : 1),
      // Report a finished game. Shows result + "play again" + suggestions of other games.
      // opts: { title, text, score, lowerIsBetter, restart }
      over(opts) {
        hideEnd();
        let isNew = false;
        if (typeof opts.score === 'number' && (opts.lowerIsBetter || opts.score > 0)) {
          const b = store.get('best_' + game.id);
          isNew = b === null || (opts.lowerIsBetter ? opts.score < b : opts.score > b);
          if (isNew) store.set('best_' + game.id, opts.score);
          updateBest();
        }
        let unlocked = false;
        if (opts.passed && s.level && s.level.cur < s.level.max) {
          const un = store.get('lvl_' + game.id, 1);
          if (s.level.cur + 1 > un) { store.set('lvl_' + game.id, s.level.cur + 1); unlocked = true; }
          s.level.draw();
        }
        showEnd(game, opts, isNew, s.level, unlocked);
      },
      hideOver: () => hideEnd(),
    };
    return { s, api };
  }

  function stopSession() {
    if (!session) return;
    session.alive = false;
    session.rafs.forEach(h => { h.stopped = true; cancelAnimationFrame(h.id); });
    session.timers.forEach(id => { clearTimeout(id); clearInterval(id); });
    session.listeners.forEach(([tg, e, f, o]) => tg.removeEventListener(e, f, o));
    session = null;
  }

  // ---------- UI ----------
  function card(g, small = false) {
    const p = played().includes(g.id);
    const badge = small ? '' : (p ? `<span class="badge done">✓</span>` : `<span class="badge new">${t('Mới', 'New')}</span>`);
    return `<button class="gm-card" data-id="${g.id}">${badge}<span class="gm-icon">${g.icon}</span>
      <b>${g.name[LANG]}</b><span class="sub">${g.name[other()]}</span>${small ? '' : `<span class="tag">${g.tag[LANG]}</span>`}</button>`;
  }
  function bindCards(el) { el.querySelectorAll('.gm-card, .daily').forEach(b => b.onclick = () => { location.hash = b.dataset.id; }); }

  function dailyGame() {
    const d = new Date(); const n = d.getFullYear() * 400 + d.getMonth() * 31 + d.getDate();
    return games[n % games.length];
  }

  function renderMenu() {
    document.documentElement.lang = LANG;
    document.querySelectorAll('[data-vi]').forEach(el => { el.innerHTML = el.dataset[LANG]; });
    $('#langBtn').textContent = LANG === 'vi' ? '🇬🇧 EN' : '🇻🇳 VI';
    const p = played().length;
    $('#hubProgress').innerHTML = t(`Bạn đã chơi <b>${p}/${games.length}</b> trò — thử hết nhé!`, `You've played <b>${p}/${games.length}</b> games — try them all!`);
    const dg = dailyGame();
    $('#daily').innerHTML = `<button class="daily" data-id="${dg.id}"><span class="gm-icon">${dg.icon}</span><span><small>⭐ ${t('Trò chơi hôm nay', "Today's game")}</small><b>${dg.name[LANG]}</b><small>${dg.tag[LANG]}</small></span></button>`;
    $('#gmGrid').innerHTML = games.map(g => card(g)).join('');
    bindCards($('#hub'));
  }

  function updateBest() {
    if (!current) return;
    const b = store.get('best_' + current.id);
    $('#gBest').textContent = b === null ? '' : `🏆 ${t('Kỷ lục', 'Best')}: ${fmtBest(current, b)}`;
  }

  function suggestions(exceptId) {
    const p = played();
    const pool = games.filter(g => g.id !== exceptId);
    pool.sort((a, b) => (p.includes(a.id) - p.includes(b.id)) || (Math.random() - 0.5)); // unplayed first
    return pool.slice(0, 3);
  }

  function showEnd(game, opts, isNew, lv, unlocked) {
    const canNext = opts.passed && lv && lv.cur < lv.max;
    const el = $('#endPanel');
    el.innerHTML = `<h3>${opts.title || t('Kết thúc!', 'Game over!')}</h3>
      ${opts.text ? `<p>${opts.text}</p>` : ''}
      ${isNew ? `<p class="new-best">🏆 ${t('Kỷ lục mới!', 'New best!')}</p>` : ''}
      ${unlocked ? `<p class="new-best">🔓 ${t(`Mở khoá cấp độ ${lv.cur + 1}!`, `Level ${lv.cur + 1} unlocked!`)}</p>` : ''}
      ${lv && opts.passed === false ? `<p>${t('Chưa qua cấp độ này — thử lại nhé!', 'Level not cleared yet — try again!')}</p>` : ''}
      <div class="btn-row" style="justify-content:center;margin-top:12px">
        ${canNext ? `<button class="btn" id="endNext">⏭ ${t(`Cấp độ ${lv.cur + 1}`, `Level ${lv.cur + 1}`)}</button>` : ''}
        <button class="btn ${canNext ? 'outline' : ''}" id="endAgain">🔁 ${t('Chơi lại', 'Play again')}</button>
        <button class="btn outline" id="endMenu">🎮 ${t('Tất cả trò chơi', 'All games')}</button>
      </div>
      <div id="endCoins" class="end-coins"></div>
      <div class="sugg-title">${t('Thử thêm trò khác nhé 👇', 'Try another game 👇')}</div>
      <div class="sugg">${suggestions(game.id).map(g => card(g, true)).join('')}</div>`;
    el.hidden = false;
    bindCards(el);
    if (typeof Account !== 'undefined') Account.onGameOver(el.querySelector('#endCoins'), game.id, lv ? lv.cur : 1, opts.passed);
    $('#endAgain').onclick = () => { hideEnd(); opts.restart && opts.restart(); };
    if (canNext) $('#endNext').onclick = () => { hideEnd(); lv.cur++; lv.draw(); lv.onChange(lv.cur); opts.restart && opts.restart(); };
    $('#endMenu').onclick = () => { location.hash = ''; };
    setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 50);
  }
  function hideEnd() { const el = $('#endPanel'); el.hidden = true; el.innerHTML = ''; }

  function route() {
    stopSession(); hideEnd();
    const g = byId(location.hash.slice(1));
    current = g || null;
    if (!g) { $('#hub').hidden = false; $('#play').hidden = true; renderMenu(); return; }
    $('#hub').hidden = true; $('#play').hidden = false;
    $('#gTitle').innerHTML = `${g.icon} ${g.name[LANG]}<small>${g.name[other()]}</small>`;
    $('#gRules').innerHTML = g.rules[LANG];
    const stage = $('#stage'); stage.innerHTML = '';
    const { s, api } = makeSession(g, stage); session = s;
    updateBest();
    markPlayed(g.id);
    g.mount(stage, api);
    window.scrollTo({ top: 0 });
  }

  function init() {
    $('#langBtn').onclick = () => { LANG = other(); store.set('lang', LANG); renderMenu(); if (current) route(); if (typeof Account !== 'undefined') Account.badge(); };
    $('#backBtn').onclick = () => { location.hash = ''; };
    window.addEventListener('hashchange', route);
    route();
  }

  return { register, init, t: (...a) => t(...a) };
})();
