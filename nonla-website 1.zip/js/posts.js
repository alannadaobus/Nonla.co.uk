// =====================================================================
// Nón Lá – BLOG POSTS (bilingual) with a publishing schedule.
// A post appears on the site automatically when its `date` (YYYY-MM-DD) has arrived.
// So you can add posts with future dates now and they will publish themselves.
//
// To add posts WITHOUT re-uploading the site, use the small Cloudflare Worker in
// worker/posts-worker.js (see HUONG-DAN.md). Posts from the Worker are merged with these.
// =====================================================================
const POSTS_REMOTE_URL = 'https://api.nonla.co.uk/posts'; // leave as is; if the Worker isn't set up the site just uses the posts below

const POSTS = [
  {
    id: 'van-hoa-viet-tam-hon-viet',
    date: '2026-11-21',
    author: 'Alanna Dao',
    cover: 'pho',
    title: {
      vi: 'Văn hóa Việt, tâm hồn Việt: Hương phở sớm mai và vành nón quê nhà',
      en: 'Vietnamese Culture, Vietnamese Soul: Morning Phở and the Curve of a Conical Hat'
    },
    excerpt: {
      vi: 'Có những thứ không cần giải thích vẫn khiến người Việt xa quê thấy lòng ấm lại: một bát phở nóng buổi sớm và chiếc nón lá nghiêng nghiêng dưới nắng.',
      en: 'Some things need no explanation to warm a Vietnamese heart far from home: a hot bowl of phở at dawn, and a conical hat tilted against the sun.'
    },
    body: {
      vi: `
<p>Có những thứ không cần giải thích vẫn khiến người Việt xa quê thấy lòng ấm lại. Với tôi, đó là mùi nước dùng phở thoảng ra từ một quán nhỏ lúc trời còn mờ sương, và hình ảnh chiếc nón lá nghiêng nghiêng trên con đường làng. Hai thứ rất bình dị ấy lại chứa đựng nhiều điều về cách người Việt sống: kiên nhẫn, tỉ mỉ và trân trọng những gì giản đơn.</p>
<h2>Bát phở – sự kiên nhẫn được nấu thành hương vị</h2>
<p>Phở ra đời ở miền Bắc vào khoảng đầu thế kỷ 20, gắn với Nam Định và Hà Nội. Bí quyết của một bát phở ngon không nằm ở sự cầu kỳ mà ở thời gian: xương bò được ninh nhiều giờ liền, gừng và hành nướng cháy vỏ cho dậy mùi, thêm hoa hồi, quế, thảo quả để nước dùng trong mà vẫn đậm sâu.</p>
<p>Phở Hà Nội thường thanh, ít rau, để vị nước dùng lên tiếng. Khi theo chân người di cư vào Nam, phở được ăn kèm nhiều rau thơm, giá đỗ, tương đen, tương ớt, mang hương vị phóng khoáng hơn. Mỗi vùng một vẻ, nhưng ở đâu phở cũng là bữa sáng của sự sum vầy: người cha dắt con đi ăn, những người bạn cũ hẹn nhau ở quán quen.</p>
<p>Vì phở xứng đáng có một buổi sáng thong thả của riêng nó, quầy ăn nhanh của Nón Lá tập trung vào bánh mì, gỏi cuốn, chả giò, những món mang đi được. Còn phở, chúng tôi muốn kể về nó bằng cả tấm lòng như trong bài viết này.</p>
<h2>Chiếc nón lá – vành tre ôm lấy nắng mưa</h2>
<p>Một chiếc nón lá truyền thống thường có mười sáu vành tre được vót tròn đều, lớp lá nón phơi khô, là phẳng, rồi được khâu tay từng mũi nhỏ. Làng Chuông (Hà Nội) và các làng nghề ở Huế là những nơi nổi tiếng với nghề làm nón. Ở Huế còn có nón bài thơ: giữa hai lớp lá là những câu thơ, hình cầu Trường Tiền, chỉ hiện ra khi soi nón lên ánh sáng.</p>
<p>Nón lá che nắng, che mưa, làm quạt khi trời oi, có lúc thành chiếc gàu múc nước bên giếng. Nhưng trên hết, nón lá là một biểu tượng của sự dịu dàng và bền bỉ, rất gần với hình ảnh người phụ nữ Việt Nam.</p>
<h2>Tâm hồn Việt nằm trong những điều giản dị</h2>
<p>Nồi nước dùng được canh lửa suốt đêm, chiếc nón được khâu qua hàng nghìn mũi chỉ: cả hai đều cần đôi tay chăm chút và một tấm lòng không vội vàng. Có lẽ tâm hồn Việt nằm chính ở đó, trong sự tận tụy với những điều nhỏ bé.</p>
<p>Lần tới khi đội một chiếc nón lá hay ngồi trước một bát phở nóng, mong bạn dừng lại một chút để cảm nhận câu chuyện phía sau.</p>`,
      en: `
<p>Some things need no explanation to warm a Vietnamese heart far from home. For me, it is the scent of phở broth drifting from a tiny shop while the morning is still misty, and the sight of a conical hat tilted along a village road. These two humble things say a great deal about how Vietnamese people live: with patience, with care, and with respect for simple things.</p>
<h2>A bowl of phở: patience turned into flavour</h2>
<p>Phở was born in northern Vietnam in the early 20th century, closely linked to Nam Định and Hà Nội. The secret of a good bowl is not complexity but time. Beef bones simmer for many hours, ginger and onion are charred to release their aroma, and star anise, cinnamon and black cardamom make the broth clear yet deep.</p>
<p>Hà Nội phở is usually delicate, with few herbs, so the broth can speak for itself. As the dish travelled south with people who moved there, it gained piles of fresh herbs, bean sprouts, hoisin and chilli sauce, and a more generous character. Every region has its own style, but everywhere phở is a breakfast of togetherness: a father taking his child out to eat, old friends meeting at their usual spot.</p>
<p>Because phở deserves an unhurried morning of its own, the Nón Lá street-food counter focuses on bánh mì, fresh rolls and crispy spring rolls, food you can take with you. Phở we would rather celebrate with our whole heart, as in this story.</p>
<h2>The conical hat: bamboo rings that hold the sun and rain</h2>
<p>A traditional nón lá usually has sixteen thin bamboo rings. Palm leaves are dried, pressed flat and stitched on by hand, one tiny stitch at a time. Chuông village near Hà Nội and the craft villages around Huế are famous for hat-making. Huế is also home to the <em>nón bài thơ</em>, the poem hat: between its layers of leaves lie lines of poetry and scenes such as the Trường Tiền bridge, visible only when you hold the hat up to the light.</p>
<p>The nón lá shades from sun and rain, works as a fan on a hot day, and has even served as a scoop at the village well. Above all, it is a symbol of gentleness and resilience, closely tied to the image of Vietnamese women.</p>
<h2>The Vietnamese soul lives in simple things</h2>
<p>A pot of broth watched over all night, a hat sewn with thousands of stitches: both need careful hands and a heart that is not in a hurry. Perhaps that is where the Vietnamese soul lives, in devotion to small things.</p>
<p>Next time you wear a conical hat or sit in front of a steaming bowl of phở, I hope you pause for a moment to feel the story behind it.</p>`
    }
  },
  {
    id: 'tho-cam-tay-bac',
    date: '2026-11-28',
    author: 'Alanna Dao',
    cover: 'thocam',
    title: {
      vi: 'Thổ cẩm – Những sợi chỉ kể chuyện núi rừng Tây Bắc',
      en: 'Thổ Cẩm: Threads That Tell the Stories of Vietnam’s Northwest'
    },
    excerpt: {
      vi: 'Mỗi tấm thổ cẩm là một cuốn sách không chữ: hoa văn hình thoi, hình sao, núi, suối… được dệt nên từ đôi tay của những người phụ nữ vùng cao.',
      en: 'Every piece of thổ cẩm is a book without words: diamonds, stars, mountains and streams woven by the hands of highland women.'
    },
    body: {
      vi: `
<p>Nếu có dịp đến những phiên chợ vùng cao Tây Bắc như Bắc Hà, Sa Pa hay Mai Châu, bạn sẽ bị cuốn hút bởi một biển màu sắc: đỏ rực, chàm sẫm, vàng nghệ, trắng ngà. Đó là thổ cẩm, loại vải dệt tay truyền thống của các dân tộc như Thái, H'Mông, Dao, Mường, Hà Nhì, Lô Lô…</p>
<h2>Từ cây lanh, sợi bông đến khung cửi</h2>
<p>Để có một tấm thổ cẩm, người phụ nữ vùng cao trải qua rất nhiều công đoạn: trồng bông hoặc lanh, tước sợi, se chỉ, nhuộm màu rồi ngồi bên khung cửi hàng tuần, có khi hàng tháng. Người H'Mông nổi tiếng với vải lanh nhuộm chàm. Họ dùng sáp ong vẽ hoa văn lên vải trước khi nhuộm, để khi giặt sáp đi, những đường nét trắng hiện lên trên nền xanh thẫm.</p>
<p>Màu sắc truyền thống thường lấy từ thiên nhiên: chàm cho màu xanh đen, củ nâu cho màu nâu, nghệ cho màu vàng. Mỗi lần nhúng chàm, màu vải lại đậm thêm một chút, và vải cũng mang theo mùi hương rất riêng của núi rừng.</p>
<h2>Hoa văn – ngôn ngữ của người vùng cao</h2>
<p>Hoa văn thổ cẩm không chỉ để trang trí. Những hình thoi, tam giác, xoắn ốc, ngôi sao, bông hoa hay con vật phản ánh thiên nhiên, tín ngưỡng và ước mong của mỗi dân tộc. Chiếc khăn piêu của cô gái Thái được thêu tỉ mỉ làm quà tặng người thương. Bộ trang phục đỏ của người Dao nổi bật với những đường thêu dày đặc. Váy xòe nhiều tầng của phụ nữ H'Mông chuyển động như cánh hoa mỗi khi họ bước đi.</p>
<p>Ngày xưa, các bé gái học dệt, học thêu từ khi còn nhỏ. Bộ váy áo tự tay làm là niềm tự hào, thể hiện sự khéo léo và chăm chỉ của người con gái.</p>
<h2>Thổ cẩm trong đời sống hôm nay</h2>
<p>Ngày nay thổ cẩm bước ra khỏi bản làng, trở thành túi xách, khăn choàng, áo khoác, viền áo sơ mi nam, đồ trang trí nhà cửa. Khi chọn mua, bạn có thể để ý: vải dệt tay thường có những điểm không hoàn toàn đều, màu nhuộm tự nhiên dịu và có chiều sâu. Mua trực tiếp từ hợp tác xã hoặc người làm nghề cũng là cách giúp nghề truyền thống được tiếp nối.</p>
<p>Mỗi tấm thổ cẩm là một cuốn sách không chữ. Khi khoác nó lên người, ta mang theo một phần câu chuyện của núi rừng Tây Bắc.</p>`,
      en: `
<p>If you ever visit a highland market in Vietnam’s Northwest, such as Bắc Hà, Sa Pa or Mai Châu, you will be swept into a sea of colour: blazing red, deep indigo, turmeric yellow, ivory white. This is <em>thổ cẩm</em>, the traditional handwoven textile of ethnic groups such as the Thái, H'Mông, Dao, Mường, Hà Nhì and Lô Lô.</p>
<h2>From hemp and cotton to the loom</h2>
<p>A single piece of thổ cẩm takes many steps. Highland women grow cotton or hemp, strip and spin the fibres, dye the thread, then sit at the loom for weeks or even months. The H'Mông are famous for indigo-dyed hemp cloth. They draw patterns on the fabric with beeswax before dyeing, so that when the wax is washed away, white lines appear on the dark blue.</p>
<p>Traditional colours come from nature: indigo for blue-black, dye yam for brown, turmeric for yellow. Each dip in the indigo vat deepens the colour a little, and the cloth carries a scent all its own, the scent of the mountains.</p>
<h2>Patterns: the language of the highlands</h2>
<p>The patterns are not just decoration. Diamonds, triangles, spirals, stars, flowers and animals reflect each community’s natural world, beliefs and hopes. A Thái girl embroiders her <em>khăn piêu</em> headscarf with great care as a gift for the one she loves. Red Dao costumes stand out with dense embroidery. The many-layered pleated skirts of H'Mông women move like flower petals as they walk.</p>
<p>In the past, girls learned to weave and embroider from a young age. An outfit made with their own hands was a source of pride, a sign of skill and diligence.</p>
<h2>Thổ cẩm in everyday life today</h2>
<p>Today thổ cẩm has travelled far beyond the villages, becoming bags, scarves, jackets, trim on men’s shirts and home décor. When buying, look closely: handwoven cloth often has small irregularities, and natural dyes look soft and deep. Buying directly from cooperatives or the makers themselves helps keep the craft alive.</p>
<p>Every piece of thổ cẩm is a book without words. When you wear it, you carry a part of the Northwest’s story with you.</p>`
    }
  },
  {
    id: 'ao-dai-dang-viet',
    date: '2026-12-05',
    author: 'Alanna Dao',
    cover: 'aodai',
    title: {
      vi: 'Áo dài – Dáng Việt thướt tha qua mọi thời đại',
      en: 'The Áo Dài: Vietnam’s Timeless Silhouette'
    },
    excerpt: {
      vi: 'Hai tà áo bay trong gió, chiếc nón nghiêng che nắng: áo dài là hình ảnh mà người Việt ở bất cứ đâu cũng nhận ra ngay.',
      en: 'Two panels fluttering in the breeze, a conical hat tilted against the sun: the áo dài is an image every Vietnamese person recognises at once.'
    },
    body: {
      vi: `
<p>Hai tà áo bay trong gió, chiếc nón lá nghiêng che nắng: áo dài là hình ảnh mà người Việt ở bất cứ đâu cũng nhận ra ngay. Nhưng chiếc áo tưởng như quen thuộc ấy đã trải qua một hành trình dài để có được dáng vẻ hôm nay.</p>
<h2>Từ áo tứ thân, áo ngũ thân…</h2>
<p>Trước khi có áo dài như ngày nay, phụ nữ Việt mặc áo tứ thân, áo giao lĩnh, rồi áo ngũ thân với năm vạt vải. Vào thế kỷ 18, chúa Nguyễn Phúc Khoát ở Đàng Trong ban hành quy định về y phục, góp phần định hình kiểu áo dài cài khuy bên hông, mặc cùng quần, khác với váy và yếm trước đó.</p>
<h2>…đến dáng áo ôm thướt tha</h2>
<p>Những năm 1930, họa sĩ Cát Tường (tên Pháp là Le Mur) ở Hà Nội thiết kế lại áo dài theo hướng ôm sát cơ thể, tôn đường cong. Họa sĩ Lê Phổ sau đó làm mềm mại thêm, mang tinh thần truyền thống trở lại. Giữa thế kỷ 20, các nhà may ở Sài Gòn đưa vào kiểu tay raglan giúp áo vừa vặn và thoải mái hơn. Đó là nền tảng của chiếc áo dài hiện đại.</p>
<h2>Một nét Việt trong đời sống</h2>
<p>Áo dài có mặt trong những khoảnh khắc quan trọng nhất của người Việt: ngày Tết, lễ cưới, lễ tốt nghiệp. Ở nhiều nơi, áo dài trắng là đồng phục của các nữ sinh, gắn với ký ức tuổi học trò. Áo dài nam với khăn đóng cũng đang được nhiều người mặc lại trong những dịp lễ trọng.</p>
<p>Điều làm nên vẻ đẹp của áo dài không chỉ là đường cắt may mà còn là tinh thần nó mang theo: kín đáo mà duyên dáng, giản dị mà sang trọng. Khi đi cùng chiếc nón lá, áo dài trở thành biểu tượng văn hóa được bạn bè quốc tế yêu mến.</p>
<h2>Gợi ý nhỏ khi mặc áo dài</h2>
<p>Chọn chất liệu theo dịp: lụa và gấm cho lễ Tết, voan hoặc chiffon nhẹ nhàng cho dạo phố. Một chiếc nón lá vẽ hoa sen hay một chiếc khăn lụa sẽ làm bộ trang phục thêm nổi bật. Và đừng quên dáng đi thong thả, vì áo dài đẹp nhất khi người mặc tự tin và nhẹ nhàng.</p>`,
      en: `
<p>Two panels fluttering in the breeze, a conical hat tilted against the sun: the áo dài is an image every Vietnamese person recognises at once. Yet this familiar garment travelled a long road to reach the shape we know today.</p>
<h2>From four-panel and five-panel robes…</h2>
<p>Before the modern áo dài, Vietnamese women wore the four-panel <em>áo tứ thân</em>, the cross-collared <em>áo giao lĩnh</em>, and later the five-panel <em>áo ngũ thân</em>. In the 18th century, Lord Nguyễn Phúc Khoát of the southern realm issued rules on clothing that helped shape a side-buttoned long tunic worn with trousers, instead of the earlier skirts and bodices.</p>
<h2>…to the graceful fitted silhouette</h2>
<p>In the 1930s, the Hà Nội painter Cát Tường (known in French as Le Mur) redesigned the áo dài to follow the body closely and flatter its curves. The painter Lê Phổ then softened the design and brought back a traditional spirit. In the mid-20th century, tailors in Saigon introduced raglan sleeves, making the dress fit better and feel more comfortable. That is the foundation of today’s áo dài.</p>
<h2>A Vietnamese touch in everyday life</h2>
<p>The áo dài appears at the most important moments of Vietnamese life: Lunar New Year, weddings, graduations. In many places a white áo dài is the uniform of schoolgirls, tied to memories of school days. The men’s áo dài with a <em>khăn đóng</em> headpiece is also coming back for special occasions.</p>
<p>The beauty of the áo dài is not only in the cut but in the spirit it carries: modest yet graceful, simple yet elegant. Paired with a conical hat, it has become a cultural symbol loved around the world.</p>
<h2>A few tips for wearing an áo dài</h2>
<p>Choose the fabric for the occasion: silk and brocade for festivals, light chiffon for a stroll in town. A hand-painted lotus hat or a silk scarf makes the outfit stand out. And take your time as you walk, because an áo dài looks its best on someone relaxed and confident.</p>`
    }
  },
];

// ---------- Cover illustrations for posts (SVG, no photos of people) ----------
const POST_COVERS = {
  pho: `<svg viewBox="0 0 400 220"><rect width="400" height="220" fill="#f6e7c4"/><circle cx="320" cy="50" r="28" fill="#f2c14e" opacity=".6"/>
    <g opacity=".5" stroke="#b38a3e" stroke-width="3" fill="none"><path d="M150 70 q10 -20 0 -40"/><path d="M180 66 q10 -20 0 -40"/><path d="M210 70 q10 -20 0 -40"/></g>
    <ellipse cx="180" cy="120" rx="110" ry="24" fill="#f4efe4" stroke="#2f6db3" stroke-width="4"/><path d="M70 120 Q80 190 180 192 Q280 190 290 120 Z" fill="#fbf8f2" stroke="#2f6db3" stroke-width="4"/>
    <path d="M90 140 Q180 150 270 140" stroke="#2f6db3" stroke-width="3" fill="none" opacity=".5"/><ellipse cx="180" cy="120" rx="96" ry="18" fill="#e9b45f"/>
    <g fill="#5e9e4a"><ellipse cx="140" cy="116" rx="12" ry="5"/><ellipse cx="205" cy="122" rx="12" ry="5" transform="rotate(30 205 122)"/></g><g fill="#b5543a"><ellipse cx="170" cy="118" rx="16" ry="6"/><ellipse cx="225" cy="114" rx="14" ry="5"/></g>
    <path d="M250 70 L330 140" stroke="#6b4a2b" stroke-width="5"/><path d="M262 64 L340 134" stroke="#6b4a2b" stroke-width="5"/>
    <g transform="translate(300 150) scale(.5)"><path d="M100 10 L176 86 Q100 104 24 86 Z" fill="#e6cf99" stroke="#7d5a2a" stroke-width="4"/></g></svg>`,
  thocam: (() => {
    let d = '';
    const cols = ['#c8261e', '#1b1b1b', '#e8b93a', '#f4f0e6', '#2f5d3a', '#2a3f8f'];
    for (let r = 0; r < 6; r++) {
      const y = r * 38, base = r % 2 ? '#1b1b1b' : '#c8261e';
      d += `<rect y="${y}" width="400" height="38" fill="${base}"/><rect y="${y}" width="400" height="4" fill="#e8b93a"/>`;
      for (let i = 0; i < 14; i++) { const cx = i * 30 + 15 + (r % 2) * 15, cy = y + 21, c = cols[(i + r * 2) % cols.length]; d += `<path d="M${cx} ${cy - 12} L${cx + 12} ${cy} L${cx} ${cy + 12} L${cx - 12} ${cy} Z" fill="${c === base ? '#f4f0e6' : c}"/><path d="M${cx} ${cy - 5} L${cx + 5} ${cy} L${cx} ${cy + 5} L${cx - 5} ${cy} Z" fill="${base}"/>`; }
    }
    return `<svg viewBox="0 0 400 220">${d}</svg>`;
  })(),
  aodai: `<svg viewBox="0 0 400 220"><rect width="400" height="220" fill="#efe7da"/><rect x="0" y="180" width="400" height="40" fill="#d8c7a8"/>
    <path d="M200 18 v14" stroke="#7d5a2a" stroke-width="3"/><path d="M150 40 Q200 26 250 40" stroke="#7d5a2a" stroke-width="4" fill="none"/>
    <path d="M185 38 Q200 46 215 38 L232 52 L262 110 L246 116 L230 82 L236 120 Q250 170 268 205 L200 198 L132 205 Q150 170 164 120 L170 82 L154 116 L138 110 L168 52 Z" fill="#fbfbf7" stroke="#cfc4b2" stroke-width="2"/>
    <path d="M200 46 L200 120" stroke="#e3dccf" stroke-width="2"/><path d="M186 40 Q200 50 214 40" stroke="#c8261e" stroke-width="2" fill="none"/>
    <g transform="translate(272 120) scale(.55)"><path d="M100 10 L176 86 Q100 104 24 86 Z" fill="#e6cf99" stroke="#7d5a2a" stroke-width="4"/><ellipse cx="100" cy="66" rx="10" ry="16" fill="#ef7fae"/></g>
    <g fill="#ef7fae" opacity=".7"><circle cx="60" cy="60" r="5"/><circle cx="80" cy="90" r="4"/><circle cx="330" cy="50" r="5"/></g></svg>`,
};

// Merge local + remote posts, keep only those whose date has arrived, newest first.
async function loadPosts() {
  let all = [...POSTS];
  try {
    const ctrl = new AbortController(); setTimeout(() => ctrl.abort(), 2500);
    const r = await fetch(POSTS_REMOTE_URL, { signal: ctrl.signal, cache: 'no-store' });
    if (r.ok) { const extra = await r.json(); if (Array.isArray(extra)) extra.forEach(p => { const i = all.findIndex(x => x.id === p.id); if (i >= 0) all[i] = p; else all.push(p); }); }
  } catch (e) { /* Worker not set up yet – fine */ }
  const today = new Date().toISOString().slice(0, 10);
  return all.filter(p => p.date <= today).sort((a, b) => b.date.localeCompare(a.date));
}
