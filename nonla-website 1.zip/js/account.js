// =====================================================================
// Nón Lá – member account client (talks to the API Worker at api.nonla.co.uk)
// Used on every page: shows the 🪙 coin badge, awards coins after games.
// =====================================================================
const Account = (() => {
  const API = window.NONLA_API || 'https://api.nonla.co.uk'; // API Worker address
  const L = () => { let l; try { l = JSON.parse(localStorage.getItem('nonla_lang')); } catch (e) { } return l === 'vi' || l === 'en' ? l : ((navigator.language || 'en').toLowerCase().startsWith('vi') ? 'vi' : 'en'); };
  const t = (vi, en) => (L() === 'vi' ? vi : en);
  const ERR = {
    bad_email: ['Email không hợp lệ', 'Please enter a valid email'],
    bad_name: ['Vui lòng nhập tên', 'Please enter your name'],
    weak_password: ['Mật khẩu cần 8–128 ký tự', 'Password must be 8–128 characters'],
    consent_required: ['Bạn cần đồng ý Điều khoản và Chính sách bảo mật', 'Please accept the Terms and Privacy Policy'],
    email_taken: ['Email này đã có tài khoản — hãy đăng nhập', 'This email already has an account — please sign in'],
    wrong_login: ['Sai email hoặc mật khẩu', 'Wrong email or password'],
    too_many_attempts: ['Thử sai quá nhiều lần. Vui lòng đợi 15 phút.', 'Too many attempts. Please wait 15 minutes.'],
    wrong_password: ['Mật khẩu hiện tại không đúng', 'Current password is incorrect'],
    not_enough_coins: ['Bạn chưa đủ xu', 'Not enough coins yet'],
    not_signed_in: ['Vui lòng đăng nhập', 'Please sign in'],
    network: ['Không kết nối được máy chủ. Thử lại sau nhé.', 'Can’t reach the server. Please try again later.'],
  };
  const errMsg = code => { const e = ERR[code]; return e ? t(e[0], e[1]) : t('Có lỗi xảy ra', 'Something went wrong') + (code ? ` (${code})` : ''); };

  let me = null, loaded = false;
  async function api(path, body) {
    let r;
    try {
      r = await fetch(API + path, { method: body ? 'POST' : 'GET', credentials: 'include', headers: body ? { 'content-type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
    } catch (e) { throw { code: 'network' }; }
    let j = {}; try { j = await r.json(); } catch (e) { }
    if (!r.ok) throw { code: j.error || 'http_' + r.status };
    return j;
  }
  async function load() {
    try { me = await api('/me'); } catch (e) { me = null; }
    loaded = true; badge(); return me;
  }
  function badge() {
    document.querySelectorAll('.acct-btn').forEach(b => {
      b.textContent = me ? `🪙 ${me.user.coins}` : t('👤 Đăng nhập', '👤 Sign in');
      b.title = me ? t('Tài khoản của bạn', 'Your account') : t('Đăng nhập / Đăng ký', 'Sign in / Join');
    });
  }
  // Called by the games page when a round ends.
  async function onGameOver(el, gameId, level, passed) {
    if (!el) return;
    if (gameId === 'baucua') { el.innerHTML = `<small>🎲 ${t('Bầu Cua là trò may rủi — chỉ để vui, không tích xu.', 'Bầu Cua is a game of chance — just for fun, no coins.')}</small>`; return; }
    if (!loaded) await load();
    if (!me) { el.innerHTML = `<a href="account.html" class="coin-cta">🪙 ${t('Đăng ký thành viên để tích xu đổi voucher giảm giá!', 'Join free to earn coins for discount vouchers!')}</a>`; return; }
    try {
      const r = await api('/coins/earn', { game: gameId, level, passed });
      if (r.earned > 0) { me.user.coins = r.coins; badge(); el.innerHTML = `<div class="coin-win">+${r.earned} 🪙 <small>${t(`Tổng: ${r.coins} xu · hôm nay còn ${r.dailyLeft} xu`, `Total: ${r.coins} coins · ${r.dailyLeft} left today`)}</small></div>`; }
      else el.innerHTML = `<small>🪙 ${r.reason === 'daily_cap' ? t('Bạn đã đạt giới hạn xu hôm nay — mai chơi tiếp nhé!', 'Daily coin limit reached — come back tomorrow!') : r.reason === 'cooldown' ? t('Chơi thêm một ván nữa để nhận xu', 'Play another round to earn coins') : ''}</small>`;
    } catch (e) { el.innerHTML = `<small>${errMsg(e.code)}</small>`; }
  }
  return { api, load, badge, onGameOver, errMsg, t, get me() { return me; } };
})();
document.addEventListener('DOMContentLoaded', () => Account.load());
