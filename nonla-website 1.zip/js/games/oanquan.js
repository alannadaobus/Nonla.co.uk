// Ô Ăn Quan – Mandarin Square Capturing
// Cells: 0 = left quan, 1..5 = top row (player 2), 6 = right quan, 7..11 = bottom row (player 1)
Core.register({
  id: 'oaq', icon: '🪨',
  name: { vi: 'Ô Ăn Quan', en: 'Mandarin Squares' },
  tag: { vi: 'Rải sỏi, ăn quan', en: 'Stone-capturing strategy' },
  rules: {
    vi: 'Chọn một ô của bạn (hàng dưới) rồi chọn hướng rải sỏi. Sau viên cuối: ô kế tiếp có sỏi → bốc lên rải tiếp; ô kế tiếp trống mà ô sau đó có sỏi → <b>ăn</b> ô đó. Quan lớn 👑 = 10 điểm. Hết cả hai ô quan thì kết thúc.',
    en: 'Pick one of your squares (bottom row), then a direction to sow the stones. After the last stone: if the next square has stones, pick them up and keep sowing; if it is empty and the one after has stones, you <b>capture</b> them. The mandarin 👑 is worth 10. The game ends when both mandarin squares are empty.'
  },
  fmtBest: (v, t) => v + t(' điểm', ' pts'),
  mount(root, api) {
    const t = api.t;
    root.innerHTML = `
      <div class="opt-row">
        <label><input type="radio" name="oaqMode" value="cpu" checked> ${t('Chơi với máy', 'vs Computer')}</label>
        <label><input type="radio" name="oaqMode" value="2p"> ${t('2 người', '2 players')}</label>
      </div>
      <div class="scores"><span class="s2"></span><span class="s1"></span></div>
      <div class="oaq-wrap"><div class="oaq-board"></div></div>
      <div class="status"></div>
      <div class="oaq-controls">
        <button class="btn small bl" disabled>◀ ${t('Trái', 'Left')}</button>
        <button class="btn small br" disabled>${t('Phải', 'Right')} ▶</button>
        <button class="btn small outline bn">${t('Ván mới', 'New game')}</button>
      </div>`;
    api.levelBar(root, 3, () => newGame());
    const $ = s => root.querySelector(s);
    const board = $('.oaq-board'), statusEl = $('.status'), btnL = $('.bl'), btnR = $('.br');
    let s, selected = null, busy = false, reported = false, gen = 0;

    const isQuan = i => i === 0 || i === 6;
    const owner = i => (i >= 1 && i <= 5) ? 2 : (i >= 7 ? 1 : 0);
    const next = (i, d) => (i + d + 12) % 12;
    const val = (st, i) => st.b[i] + (isQuan(i) && st.big[i] ? 10 : 0);
    const notEmpty = (st, i) => st.b[i] > 0 || (isQuan(i) && st.big[i]);
    const mode = () => root.querySelector('input[name=oaqMode]:checked').value;
    const name = p => p === 1 ? (mode() === 'cpu' ? t('Bạn', 'You') : t('Người 1', 'Player 1')) : (mode() === 'cpu' ? t('Máy', 'CPU') : t('Người 2', 'Player 2'));
    const fresh = () => ({ b: [0, 5, 5, 5, 5, 5, 0, 5, 5, 5, 5, 5], big: { 0: true, 6: true }, score: { 1: 0, 2: 0 }, turn: 1, over: false });
    const clone = st => ({ b: [...st.b], big: { ...st.big }, score: { ...st.score }, turn: st.turn, over: st.over });
    const sideCells = p => p === 1 ? [7, 8, 9, 10, 11] : [1, 2, 3, 4, 5];

    function play(st, cell, dir, steps = []) {
      let hand = st.b[cell]; st.b[cell] = 0; let i = cell, guard = 0;
      steps.push({ pick: cell });
      while (guard++ < 500) {
        while (hand > 0) { i = next(i, dir); st.b[i]++; hand--; steps.push({ drop: i }); }
        const n = next(i, dir);
        if (isQuan(n) && notEmpty(st, n)) break;
        if (st.b[n] > 0) { hand = st.b[n]; st.b[n] = 0; i = n; steps.push({ pick: n }); continue; }
        let e = n;
        while (true) {
          const tt = next(e, dir);
          if (!notEmpty(st, tt)) break;
          st.score[st.turn] += val(st, tt); st.b[tt] = 0; if (isQuan(tt)) st.big[tt] = false;
          steps.push({ cap: tt });
          const after = next(tt, dir);
          if (notEmpty(st, after)) break;
          e = after;
        }
        break;
      }
      endTurn(st);
      return steps;
    }
    function endTurn(st) {
      if (!notEmpty(st, 0) && !notEmpty(st, 6)) { finish(st); return; }
      st.turn = st.turn === 1 ? 2 : 1;
      const cells = sideCells(st.turn);
      if (cells.every(c => st.b[c] === 0)) {
        if (st.score[st.turn] >= 5) { cells.forEach(c => st.b[c] = 1); st.score[st.turn] -= 5; st.refilled = true; }
        else finish(st);
      }
    }
    function finish(st) {
      [1, 2].forEach(p => sideCells(p).forEach(c => { st.score[p] += st.b[c]; st.b[c] = 0; }));
      st.over = true;
    }

    function render(highlight) {
      board.innerHTML = '';
      [0, 1, 2, 3, 4, 5, 6, 11, 10, 9, 8, 7].forEach(i => {
        const d = document.createElement('div');
        d.className = 'oaq-cell' + (isQuan(i) ? ' quan' + (i === 6 ? ' right' : '') : '');
        if (i === 0) d.style.gridColumn = '1';
        if (i === 6) { d.style.gridColumn = '7'; d.style.gridRow = '1 / span 2'; }
        if (i >= 1 && i <= 5) { d.style.gridColumn = String(i + 1); d.style.gridRow = '1'; }
        if (i >= 7) { d.style.gridColumn = String(13 - i); d.style.gridRow = '2'; }
        const canPlay = !s.over && !busy && s.b[i] > 0 && owner(i) === s.turn && !(mode() === 'cpu' && s.turn === 2);
        if (canPlay) { d.classList.add('playable'); d.onclick = () => { selected = i; render(); setStatus(); }; }
        if (i === selected) d.classList.add('selected');
        if (i === highlight) d.classList.add('flash');
        d.innerHTML = (isQuan(i) && s.big[i] ? '<span class="big">👑</span>' : '') +
          `<span>${val(s, i)}</span><div class="seeds">${'<i></i>'.repeat(Math.min(s.b[i], 20))}</div>` +
          (isQuan(i) ? `<span class="lbl">${t('Quan', 'Mandarin')}</span>` : '');
        board.appendChild(d);
      });
      $('.s1').textContent = `${name(1)}: ${s.score[1]}`;
      $('.s2').textContent = `${name(2)}: ${s.score[2]}`;
      btnL.disabled = btnR.disabled = selected === null;
    }

    function setStatus() {
      if (s.over) {
        const a = s.score[1], b = s.score[2];
        statusEl.textContent = a === b ? t(`Hoà ${a} – ${b}!`, `Draw ${a} – ${b}!`) : `🎉 ${a > b ? name(1) : name(2)} ${t('thắng', 'wins')} ${Math.max(a, b)} – ${Math.min(a, b)}!`;
        if (!reported) {
          reported = true;
          const cpu = mode() === 'cpu';
          api.over({
            title: cpu ? (a > b ? t('Bạn thắng! 🎉', 'You win! 🎉') : a === b ? t('Hoà!', 'Draw!') : t('Máy thắng rồi 😅', 'The computer wins 😅')) : statusEl.textContent,
            text: `${name(1)} ${a} – ${b} ${name(2)}`,
            score: cpu && a > b ? a : undefined, passed: cpu ? a > b : undefined,
            restart: newGame
          });
        }
      } else {
        statusEl.textContent = (s.refilled ? t(`${name(s.turn)} hết sỏi, rải lại 5 viên. `, `${name(s.turn)} ran out — 5 stones put back. `) : '') +
          `${t('Lượt', 'Turn')}: ${name(s.turn)}` + (selected !== null ? t(' — chọn hướng', ' — choose a direction') : '');
        s.refilled = false;
      }
    }

    async function animate(steps) {
      const disp = clone(s);
      for (const st2 of steps) {
        if (!api.alive() || !busy) return;
        if (st2.pick !== undefined) disp.b[st2.pick] = 0;
        if (st2.drop !== undefined) disp.b[st2.drop]++;
        if (st2.cap !== undefined) { disp.b[st2.cap] = 0; if (isQuan(st2.cap)) disp.big[st2.cap] = false; }
        const keep = s; s = disp; render(st2.drop ?? st2.pick ?? st2.cap); s = keep;
        await api.sleep(st2.cap !== undefined ? 450 : 160);
      }
    }

    async function doMove(cell, dir) {
      busy = true; selected = null; const g = gen;
      const st = clone(s);
      const steps = play(st, cell, dir);
      await animate(steps);
      if (!api.alive() || g !== gen) return;
      s = st; busy = false; render(); setStatus();
      if (!s.over && mode() === 'cpu' && s.turn === 2) { await api.sleep(500); if (api.alive() && g === gen) cpuMove(); }
    }

    // AI by level: 1 = mostly random, 2 = greedy, 3 = looks ahead at your best reply
    function moves(st, p) { const m = []; sideCells(p).forEach(c => { if (st.b[c]) { m.push([c, 1]); m.push([c, -1]); } }); return m; }
    function cpuMove() {
      const lv = api.level(), ms = moves(s, 2);
      if (!ms.length) return;
      if (lv === 1 && Math.random() < 0.7) { const [c, d] = ms[Math.floor(Math.random() * ms.length)]; doMove(c, d); return; }
      let best = null;
      for (const [c, d] of ms) {
        const tt = clone(s); tt.turn = 2; play(tt, c, d);
        let val = tt.score[2] - s.score[2] - (tt.score[1] - s.score[1]);
        if (lv === 3 && !tt.over && tt.turn === 1) {
          let worst = 0;
          for (const [c2, d2] of moves(tt, 1)) { const u = clone(tt); play(u, c2, d2); worst = Math.max(worst, (u.score[1] - tt.score[1]) - (u.score[2] - tt.score[2])); }
          val -= worst;
        }
        val += Math.random() * 0.4;
        if (!best || val > best.val) best = { c, d, val };
      }
      doMove(best.c, best.d);
    }

    function newGame() { gen++; s = fresh(); selected = null; busy = false; reported = false; api.hideOver(); render(); setStatus(); }

    btnL.onclick = () => selected !== null && doMove(selected, owner(selected) === 1 ? 1 : -1);
    btnR.onclick = () => selected !== null && doMove(selected, owner(selected) === 1 ? -1 : 1);
    $('.bn').onclick = newGame;
    root.querySelectorAll('input[name=oaqMode]').forEach(r => r.onchange = newGame);
    newGame();
  }
});
