// Đánh Chuyền – Sticks & Ball (Vietnamese jacks)
Core.register({
  id: 'danhchuyen', icon: '🥢',
  name: { vi: 'Đánh Chuyền', en: 'Sticks & Ball' },
  tag: { vi: 'Tung bóng, nhặt que', en: 'Toss, pick, catch' },
  rules: {
    vi: 'Bấm <b>Tung bóng</b>. Trong lúc bóng bay, nhặt <b>đúng số que</b> được yêu cầu rồi chạm vào bóng để <b>bắt</b> trước khi bóng rơi. Nhặt hết que thì lên bàn mới — phải nhặt nhiều que hơn mỗi lần.',
    en: 'Press <b>Toss</b>. While the ball is in the air, pick up the <b>required number of sticks</b>, then tap the ball to <b>catch</b> it before it lands. Clear all sticks to move up a level — you must pick more sticks each toss.'
  },
  fmtBest: (v, t) => v + t(' lượt', ' tosses'),
  mount(root, api) {
    const t = api.t;
    root.innerHTML = `<div class="hud"><span class="lv"></span><span class="sc"></span></div>
      <div class="dc-board"><div class="dc-shadow"></div><div class="dc-ball"></div><div class="dc-hand"></div></div>
      <div class="status"></div>
      <div class="btn-line"><button class="tap-btn green toss">🟠 ${t('Tung bóng', 'Toss')}</button></div>`;
    const $ = s => root.querySelector(s);
    const board = $('.dc-board'), ball = $('.dc-ball'), shadow = $('.dc-shadow'), statusEl = $('.status'), tossBtn = $('.toss');
    const baseTop = 240, maxH = 200;
    let level, score, sticks, flying = false, picked, need, ft, dur, over = false;

    function layout() {
      board.querySelectorAll('.stick').forEach(s => s.remove());
      sticks = [];
      for (let i = 0; i < 10; i++) {
        const el = document.createElement('div'); el.className = 'stick';
        el.style.left = (8 + Math.random() * 80) + '%';
        el.style.top = (45 + Math.random() * 35) + '%';
        el.style.transform = `rotate(${Math.random() * 180}deg)`;
        api.on(el, 'pointerdown', e => { e.preventDefault(); e.stopPropagation(); pick(el); });
        board.appendChild(el); sticks.push(el);
      }
    }
    function hud() {
      $('.lv').textContent = `${t('Bàn', 'Level')} ${level}`;
      $('.sc').textContent = `⭐ ${score}`;
      $('.dc-hand').textContent = `✋ ${picked}/${need}`;
    }
    function setNeed() { need = Math.min(level, sticks.length); }
    function placeBall(h) { ball.style.top = (baseTop - h) + 'px'; shadow.style.top = (baseTop + 34) + 'px'; shadow.style.transform = `scale(${1 - h / maxH * 0.5})`; }

    function pick(el) {
      if (!flying || picked >= need) return;
      el.remove(); sticks = sticks.filter(s => s !== el); picked++; hud();
    }
    function toss() {
      if (flying || over) return;
      api.hideOver();
      flying = true; picked = 0; setNeed(); ft = 0; dur = Math.max(1.05, 1.9 - level * 0.13);
      statusEl.textContent = t(`Nhặt ${need} que rồi bắt bóng!`, `Pick ${need} stick${need > 1 ? 's' : ''}, then catch!`);
      tossBtn.disabled = true; hud();
    }
    function fail(msg) {
      flying = false; over = true; placeBall(0); tossBtn.disabled = true;
      statusEl.textContent = msg;
      api.over({ title: msg, text: t(`Bạn đạt bàn ${level} với ${score} lượt thành công.`, `You reached level ${level} with ${score} successful tosses.`), score, restart: start });
    }
    api.on(ball, 'pointerdown', e => {
      e.preventDefault();
      if (!flying) { toss(); return; }
      if (picked < need) { fail(t('Chưa nhặt đủ que! 🥢', 'Not enough sticks! 🥢')); return; }
      flying = false; score++; placeBall(0); tossBtn.disabled = false;
      if (!sticks.length) {
        level++; layout(); picked = 0; setNeed();
        statusEl.textContent = t(`🎉 Lên bàn ${level}! Mỗi lần nhặt ${Math.min(level, 10)} que.`, `🎉 Level ${level}! Pick ${Math.min(level, 10)} at a time.`);
      } else statusEl.textContent = t('Bắt được! Tung tiếp nào.', 'Caught! Toss again.');
      picked = 0; setNeed(); hud();
    });
    tossBtn.onclick = toss;

    function start() {
      api.hideOver(); level = 1; score = 0; over = false; flying = false; picked = 0; layout(); setNeed(); placeBall(0);
      tossBtn.disabled = false; statusEl.textContent = t('Bấm Tung bóng để bắt đầu', 'Press Toss to start'); hud();
    }
    api.loop(dt => {
      if (!flying) return;
      ft += dt; const p = ft / dur;
      if (p >= 1) { fail(t('Rơi bóng rồi! 🟠', 'You dropped the ball! 🟠')); return; }
      placeBall(4 * maxH * p * (1 - p));
    });
    start();
  }
});
