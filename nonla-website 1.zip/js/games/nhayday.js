// Nhảy Dây – Jump Rope
Core.register({
  id: 'nhayday', icon: '🤸',
  name: { vi: 'Nhảy Dây', en: 'Jump Rope' },
  tag: { vi: 'Canh dây mà nhảy', en: 'Time your jumps' },
  rules: {
    vi: 'Hai bạn quay dây ngày càng nhanh. Chạm màn hình để nhảy qua khi dây chạm đất. Vấp dây là thua!',
    en: 'Two friends swing the rope faster and faster. Tap to jump over it as it hits the ground. Trip on the rope and you’re out!'
  },
  fmtBest: (v, t) => v + t(' lần', ' jumps'),
  mount(root, api) {
    const t = api.t;
    root.innerHTML = `<div class="goal"></div><div class="hud"><span class="sc"></span><span class="sp"></span></div><div class="cvw"></div>
      <div class="btn-line"><button class="tap-btn green jump">⬆ ${t('NHẢY!', 'JUMP!')}</button></div>
      <div class="oaq-controls"><button class="btn start">▶ ${t('Bắt đầu', 'Start')}</button></div>`;
    const LV = { p0: [1.5, 1.3, 1.12, 0.98, 0.86], min: [0.72, 0.65, 0.58, 0.52, 0.47], goal: [10, 15, 20, 25, 30] }, L = () => api.level() - 1;
    api.levelBar(root, 5, () => { running = false; dead = false; reset(); hud(); root.querySelector('.start').hidden = false; api.hideOver(); });
    const { cv, ctx, W, H } = api.canvas(root.querySelector('.cvw'), 0.7);
    const groundY = H * 0.84, handY = H * 0.5, topY = H * 0.08;
    const cyBottom = 2 * groundY - handY, cyTop = 2 * topY - handY, mid = (cyBottom + cyTop) / 2, amp = (cyBottom - cyTop) / 2;
    let running = false, ang, period, score, jumpT, jumpDur, passed, dead;

    function reset() { ang = Math.PI; period = LV.p0[L()]; score = 0; jumpT = -1; passed = Math.floor((ang - 0.4) / (2 * Math.PI)); dead = false; }
    function hud() {
      root.querySelector('.sc').textContent = `🤸 ${score}`;
      root.querySelector('.goal').innerHTML = `🎯 ${t('Mục tiêu', 'Goal')}: ${LV.goal[L()]} ${t('lần nhảy', 'jumps')}${score >= LV.goal[L()] ? ' ✅' : ''}`;
      root.querySelector('.sp').textContent = `⚡ ${(1.5 / period).toFixed(1)}x`;
    }
    function jump() { if (!running || jumpT >= 0) return; jumpT = 0; jumpDur = Math.min(0.5, period * 0.55); }
    api.on(cv, 'pointerdown', e => { e.preventDefault(); jump(); });
    api.on(root.querySelector('.jump'), 'pointerdown', e => { e.preventDefault(); jump(); });
    api.on(window, 'keydown', e => { if (e.code === 'Space') { e.preventDefault(); jump(); } });
    function start() { api.hideOver(); reset(); running = true; hud(); root.querySelector('.start').hidden = true; }
    root.querySelector('.start').onclick = start;
    reset();

    function rope(front) {
      const cy = mid + amp * Math.cos(ang);
      const isFront = Math.sin(ang) > 0;
      if (isFront !== front) return;
      ctx.strokeStyle = '#a3271f'; ctx.lineWidth = 4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(W * 0.14, handY); ctx.quadraticCurveTo(W / 2, cy, W * 0.86, handY); ctx.stroke();
    }

    api.loop(dt => {
      if (running) {
        ang += dt * 2 * Math.PI / period;
        if (jumpT >= 0) { jumpT += dt; if (jumpT >= jumpDur) jumpT = -1; }
        const nearBottom = Math.cos(ang) > 0.93;
        if (nearBottom && jumpT < 0) {
          running = false; dead = true; root.querySelector('.start').hidden = false;
          api.over({ title: t('Vấp dây rồi! 🙈', 'Tripped on the rope! 🙈'), text: t(`Bạn nhảy được ${score} lần.`, `You made ${score} jumps.`), score, passed: score >= LV.goal[L()], restart: start });
        }
        const p = Math.floor((ang - 0.4) / (2 * Math.PI));
        if (p > passed && running) { passed = p; score++; period = Math.max(LV.min[L()], period * 0.97); hud(); }
      }
      ctx.fillStyle = '#dff0ff'; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#a9cf8a'; ctx.fillRect(0, groundY, W, H - groundY);
      ctx.fillStyle = '#93bd73'; ctx.fillRect(0, groundY, W, 4);
      rope(false);
      ctx.fillStyle = '#000'; ctx.font = '54px serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('🧒', W * 0.08, handY + 18); ctx.fillText('👧', W * 0.92, handY + 18);
      const jh = jumpT >= 0 ? Math.sin(Math.PI * jumpT / jumpDur) * H * 0.2 : 0;
      ctx.fillStyle = 'rgba(0,0,0,.15)'; ctx.beginPath(); ctx.ellipse(W / 2, groundY + 4, 20 - jh / 10, 5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#000'; ctx.font = '58px serif'; ctx.fillText(dead ? '😵' : (jh > 2 ? '🤸' : '🧍'), W / 2, groundY - 28 - jh);
      rope(true);
      if (!running && !dead) { ctx.fillStyle = '#2a1d14'; ctx.font = '600 16px "Be Vietnam Pro", sans-serif'; ctx.fillText(t('Nhảy khi dây chạm đất', 'Jump when the rope hits the ground'), W / 2, H * 0.12); }
    });
    hud();
  }
});
