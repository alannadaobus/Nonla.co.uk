// Nhảy Sạp – Bamboo Dance, with animated villagers in ethnic costumes
Core.register({
  id: 'nhaysap', icon: '🎋',
  name: { vi: 'Nhảy Sạp', en: 'Bamboo Dance' },
  tag: { vi: 'Nhảy theo nhịp tre', en: 'Jump to the bamboo beat' },
  rules: {
    vi: 'Hai người giữ sạp gõ tre theo nhịp <b>"Cạch – Cạch – Chập!"</b>. Chạm màn hình (hoặc nút NHẢY) để cô gái nhảy lên đúng lúc tre <b>chập</b> lại — đừng để bị kẹp chân! Mỗi cấp độ nhịp nhanh hơn.',
    en: 'Two pole holders clap the bamboo in a rhythm: <b>"Clack – Clack – CLAP!"</b>. Tap the screen (or JUMP) so the dancer leaps just as the poles <b>clap</b> together — don’t get caught! Each level is faster.'
  },
  fmtBest: (v, t) => v + t(' nhịp', ' beats'),
  mount(root, api) {
    const t = api.t;
    root.innerHTML = `<div class="goal"></div><div class="hud"><span class="sc"></span><span class="sp"></span></div><div class="cvw"></div>
      <div class="btn-line"><button class="tap-btn green jump">⬆ ${t('NHẢY!', 'JUMP!')}</button></div>
      <div class="oaq-controls"><button class="btn start">▶ ${t('Bắt đầu', 'Start')}</button></div>`;
    const LV = { b0: [0.75, 0.66, 0.58, 0.5, 0.44], min: [0.42, 0.38, 0.34, 0.31, 0.28], goal: [10, 15, 20, 25, 30] }, L = () => api.level() - 1;
    api.levelBar(root, 5, () => { running = false; dead = false; reset(); hud(); root.querySelector('.start').hidden = false; api.hideOver(); });
    const { cv, ctx, W, H } = api.canvas(root.querySelector('.cvw'), 0.78);
    const groundY = H * 0.74, x0 = W * 0.17, x1 = W * 0.83, open = H * 0.17;
    let running = false, beat, cyc, score, jumpT, jumpDur, lastBeat, word, wordLife, dead, time = 0, deadT = 0;

    function reset() { beat = LV.b0[L()]; cyc = 0; score = 0; jumpT = -1; lastBeat = -1; word = ''; wordLife = 0; dead = false; deadT = 0; }
    function hud() {
      root.querySelector('.sc').textContent = `🎋 ${score}`;
      root.querySelector('.sp').textContent = `♩ ${Math.round(60 / beat)} BPM`;
      root.querySelector('.goal').innerHTML = `🎯 ${t('Mục tiêu', 'Goal')}: ${LV.goal[L()]} ${t('nhịp', 'beats')}${score >= LV.goal[L()] ? ' ✅' : ''}`;
    }
    function jump() { if (!running || jumpT >= 0) return; jumpT = 0; jumpDur = Math.max(0.3, beat * 0.95); }
    api.on(cv, 'pointerdown', e => { e.preventDefault(); jump(); });
    api.on(root.querySelector('.jump'), 'pointerdown', e => { e.preventDefault(); jump(); });
    api.on(window, 'keydown', e => { if (e.code === 'Space') { e.preventDefault(); jump(); } });
    function start() { api.hideOver(); reset(); running = true; hud(); root.querySelector('.start').hidden = true; }
    root.querySelector('.start').onclick = start;

    function gapNow() {
      const c = (cyc % 1) * 3, idx = Math.floor(c), frac = c - idx;
      if (idx < 2) return { f: 1 - 0.07 * Math.sin(Math.PI * frac), idx, frac };
      return { f: 1 - Math.sin(Math.PI * frac), idx, frac };
    }

    // ---------- drawing helpers ----------
    const SKIN = '#e9b98c', HAIR = '#1d1410';
    function limb(x1, y1, x2, y2, w, col) { ctx.strokeStyle = col; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
    function limb2(x1, y1, xm, ym, x2, y2, w, col) { ctx.strokeStyle = col; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(xm, ym); ctx.lineTo(x2, y2); ctx.stroke(); }
    function face(x, y, r, sad) {
      ctx.fillStyle = SKIN; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
      ctx.fillStyle = HAIR; ctx.beginPath(); ctx.arc(x - r * 0.35, y + r * 0.05, r * 0.11, 0, 7); ctx.arc(x + r * 0.35, y + r * 0.05, r * 0.11, 0, 7); ctx.fill();
      ctx.strokeStyle = '#8a3b2a'; ctx.lineWidth = 1.4; ctx.beginPath();
      if (sad) ctx.arc(x, y + r * 0.62, r * 0.28, Math.PI * 1.15, Math.PI * 1.85); else ctx.arc(x, y + r * 0.3, r * 0.3, 0.2, Math.PI - 0.2);
      ctx.stroke();
      ctx.fillStyle = 'rgba(220,90,80,.35)'; ctx.beginPath(); ctx.arc(x - r * 0.55, y + r * 0.35, r * 0.16, 0, 7); ctx.arc(x + r * 0.55, y + r * 0.35, r * 0.16, 0, 7); ctx.fill();
    }
    function brocade(x, y, w, h, base = '#1b1b1b') { // woven band: diamonds in red/white with yellow edges
      ctx.fillStyle = base; ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#e8b93a'; ctx.fillRect(x, y, w, Math.max(1, h * 0.14)); ctx.fillRect(x, y + h - Math.max(1, h * 0.14), w, Math.max(1, h * 0.14));
      const n = Math.max(2, Math.floor(w / (h * 0.9)));
      for (let i = 0; i < n; i++) {
        const cx = x + (i + 0.5) * w / n, cy = y + h / 2, rr = h * 0.28;
        ctx.fillStyle = i % 2 ? '#f4f0e6' : '#c8261e';
        ctx.beginPath(); ctx.moveTo(cx, cy - rr); ctx.lineTo(cx + rr, cy); ctx.lineTo(cx, cy + rr); ctx.lineTo(cx - rr, cy); ctx.fill();
      }
    }

    // Dancer – red festival dress with woven bands, striped skirt, red headdress with yellow tassels
    function drawDancer(x, feetY, s, ph, jumpP, fallen) {
      ctx.save(); ctx.translate(x, feetY);
      if (fallen) { ctx.rotate(-1.25); ctx.translate(-4 * s, 4 * s); }
      const lift = jumpP > 0 ? Math.sin(Math.PI * jumpP) : 0;
      const step = Math.sin(ph * Math.PI * 2);           // stepping in place between beats
      const hipY = -34 * s + (lift ? 4 * s * lift : Math.abs(step) * 1.2 * s);
      const sway = step * 2.2 * s * (1 - lift);
      // legs
      if (lift > 0.05) {
        limb2(-4 * s, hipY, -9 * s, hipY + 10 * s, -5 * s, hipY + 19 * s, 5 * s, SKIN);
        limb2(4 * s, hipY, 10 * s, hipY + 9 * s, 6 * s, hipY + 18 * s, 5 * s, SKIN);
      } else {
        limb2(-4 * s, hipY, -6 * s - step * 3 * s, -14 * s, -6 * s, 0, 5 * s, SKIN);
        limb2(4 * s, hipY, 6 * s + step * 3 * s, -14 * s, 6 * s, 0, 5 * s, SKIN);
      }
      ctx.fillStyle = '#2a1d14'; ctx.fillRect(-10 * s, (lift > 0.05 ? hipY + 17 * s : -2 * s), 8 * s, 3 * s); ctx.fillRect(2 * s, (lift > 0.05 ? hipY + 16 * s : -2 * s), 8 * s, 3 * s);
      // skirt (striped bands) – flares a little when jumping
      const flare = 1 + 0.25 * lift + 0.05 * Math.abs(step);
      const sk = [['#d4311f', 0], ['#f08a24', 0.22], ['#1d1d1d', 0.36], ['#d4311f', 0.48], ['#f2c14e', 0.7], ['#d4311f', 0.82]];
      const skTop = hipY - 4 * s, skBot = hipY + 20 * s;
      ctx.save(); ctx.beginPath(); ctx.moveTo(-9 * s + sway, skTop); ctx.lineTo(9 * s + sway, skTop); ctx.lineTo(15 * s * flare, skBot); ctx.lineTo(-15 * s * flare, skBot); ctx.closePath(); ctx.clip();
      sk.forEach(([c, f], i) => { const nf = sk[i + 1] ? sk[i + 1][1] : 1; ctx.fillStyle = c; ctx.fillRect(-20 * s, skTop + (skBot - skTop) * f, 40 * s, (skBot - skTop) * (nf - f) + 1); });
      ctx.restore();
      // white sash
      ctx.fillStyle = '#f7f3ea'; ctx.fillRect(-10 * s + sway, hipY - 6 * s, 20 * s, 3.5 * s);
      limb(-3 * s + sway, hipY - 3 * s, -5 * s + sway * 1.4, hipY + 16 * s, 2.5 * s, '#f7f3ea');
      // torso
      const shY = hipY - 26 * s;
      ctx.fillStyle = '#d4311f'; ctx.beginPath(); ctx.moveTo(-9 * s + sway, hipY - 5 * s); ctx.lineTo(-11 * s + sway, shY + 3 * s); ctx.quadraticCurveTo(sway, shY - 2 * s, 11 * s + sway, shY + 3 * s); ctx.lineTo(9 * s + sway, hipY - 5 * s); ctx.fill();
      brocade(-9 * s + sway, shY + 6 * s, 18 * s, 6 * s);
      ctx.fillStyle = '#1d1d1d'; ctx.beginPath(); ctx.moveTo(-3 * s + sway, shY + 1 * s); ctx.lineTo(sway, shY + 6 * s); ctx.lineTo(3 * s + sway, shY + 1 * s); ctx.fill();
      // arms: graceful sway; up when jumping
      const aL = lift > 0.05 ? [-16 * s, shY - 12 * s, -20 * s, shY - 22 * s] : [-14 * s, shY + 10 * s - step * 3 * s, -21 * s, shY + 4 * s - step * 6 * s];
      const aR = lift > 0.05 ? [16 * s, shY - 12 * s, 20 * s, shY - 22 * s] : [14 * s, shY + 10 * s + step * 3 * s, 21 * s, shY + 4 * s + step * 6 * s];
      limb2(-10 * s + sway, shY + 4 * s, aL[0] + sway, aL[1], aL[2] + sway, aL[3], 4.5 * s, '#d4311f');
      limb2(10 * s + sway, shY + 4 * s, aR[0] + sway, aR[1], aR[2] + sway, aR[3], 4.5 * s, '#d4311f');
      ctx.fillStyle = SKIN; ctx.beginPath(); ctx.arc(aL[2] + sway, aL[3], 2.4 * s, 0, 7); ctx.arc(aR[2] + sway, aR[3], 2.4 * s, 0, 7); ctx.fill();
      // head + headdress with tassels
      const hx = sway * 1.2, hy = shY - 8 * s;
      ctx.fillStyle = HAIR; ctx.beginPath(); ctx.arc(hx, hy, 7.6 * s, 0, 7); ctx.fill();
      face(hx, hy + 0.5 * s, 6.6 * s, fallen);
      ctx.fillStyle = '#c8261e'; ctx.beginPath(); ctx.ellipse(hx, hy - 6 * s, 10 * s, 4.5 * s, 0, Math.PI, 0); ctx.fill();
      brocade(hx - 10 * s, hy - 7 * s, 20 * s, 3.6 * s, '#c8261e');
      const tw = Math.sin(time * 6) * 2 * s + lift * 4 * s;
      for (let k = -1; k <= 1; k += 2) for (let j = 0; j < 4; j++) limb(hx + k * (8 + j) * s, hy - 4 * s, hx + k * (10 + j * 1.5) * s + tw * k * 0.5, hy + (10 + j * 2) * s - lift * 3 * s, 1.3 * s, j % 2 ? '#f2c14e' : '#f08a24');
      ctx.restore();
    }

    // Pole holder – black shirt with woven trim, kneeling; hands follow the pole ends
    function drawHolder(x, y, s, flip, hand1, hand2, bob) {
      ctx.save(); ctx.translate(x, y + bob);
      const f = flip ? -1 : 1;
      // folded legs
      ctx.fillStyle = '#1b1b1b'; ctx.beginPath(); ctx.ellipse(-f * 4 * s, -6 * s, 13 * s, 6 * s, 0, 0, 7); ctx.fill();
      brocade(-f * 4 * s - 12 * s, -3 * s, 24 * s, 3.5 * s);
      // torso
      const sx = 0, sy = -38 * s;
      ctx.fillStyle = '#1b1b1b'; ctx.beginPath(); ctx.moveTo(-10 * s, -10 * s); ctx.lineTo(-11 * s, sy + 4 * s); ctx.quadraticCurveTo(0, sy - 1 * s, 11 * s, sy + 4 * s); ctx.lineTo(10 * s, -10 * s); ctx.fill();
      brocade(-2.5 * s, sy + 3 * s, 5 * s, 24 * s);
      ctx.fillStyle = '#e8b93a'; ctx.fillRect(-6 * s, sy + 3 * s, 1.2 * s, 24 * s); ctx.fillRect(5 * s, sy + 3 * s, 1.2 * s, 24 * s);
      ctx.fillStyle = '#c8261e'; ctx.beginPath(); ctx.arc(0, sy + 2 * s, 4.5 * s, 0, Math.PI); ctx.fill();
      // arms to the two pole ends (in local coords)
      const sh = [f * 8 * s, sy + 6 * s];
      [hand1, hand2].forEach((h, i) => {
        const hx = h.x - x, hy = h.y - y - bob;
        const mx = (sh[0] + hx) / 2 + f * 3 * s, my = (sh[1] + hy) / 2 + 6 * s;
        limb2(sh[0] - f * i * 5 * s, sh[1], mx, my, hx, hy, 4.5 * s, '#1b1b1b');
        ctx.fillStyle = SKIN; ctx.beginPath(); ctx.arc(hx, hy, 2.6 * s, 0, 7); ctx.fill();
      });
      ctx.fillStyle = HAIR; ctx.beginPath(); ctx.arc(0, sy - 9 * s, 7.4 * s, Math.PI, 0); ctx.fill();
      face(0, sy - 8 * s, 6.5 * s, false);
      ctx.restore();
    }

    function drawScene(g) {
      // sky, mountains, stilt house, festival flags
      const sky = ctx.createLinearGradient(0, 0, 0, groundY); sky.addColorStop(0, '#bfe1f2'); sky.addColorStop(1, '#f6e7c4');
      ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#8fb39a'; ctx.beginPath(); ctx.moveTo(0, groundY - H * 0.25); ctx.lineTo(W * 0.2, groundY - H * 0.42); ctx.lineTo(W * 0.42, groundY - H * 0.27); ctx.lineTo(W * 0.66, groundY - H * 0.47); ctx.lineTo(W, groundY - H * 0.28); ctx.lineTo(W, groundY); ctx.lineTo(0, groundY); ctx.fill();
      ctx.fillStyle = '#6f9a7c'; ctx.beginPath(); ctx.moveTo(0, groundY - H * 0.12); ctx.quadraticCurveTo(W * 0.3, groundY - H * 0.24, W * 0.55, groundY - H * 0.12); ctx.quadraticCurveTo(W * 0.8, groundY - H * 0.2, W, groundY - H * 0.1); ctx.lineTo(W, groundY); ctx.lineTo(0, groundY); ctx.fill();
      // nhà sàn
      const hx = W * 0.72, hy = groundY - H * 0.18;
      ctx.fillStyle = '#6b4a2b'; for (let i = 0; i < 4; i++) ctx.fillRect(hx + i * W * 0.055, hy, 3, H * 0.1);
      ctx.fillStyle = '#9c7448'; ctx.fillRect(hx - 4, hy - H * 0.08, W * 0.2, H * 0.08);
      ctx.fillStyle = '#5b3d22'; ctx.beginPath(); ctx.moveTo(hx - 14, hy - H * 0.08); ctx.lineTo(hx + W * 0.1 - 2, hy - H * 0.2); ctx.lineTo(hx + W * 0.2 + 10, hy - H * 0.08); ctx.fill();
      // flags
      const fc = ['#c8261e', '#e8b93a', '#2f6db3', '#2f5d3a'];
      ctx.strokeStyle = '#6b4a2b'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(0, 14); ctx.quadraticCurveTo(W / 2, 34, W, 14); ctx.stroke();
      for (let i = 0; i < 18; i++) { const x = i * W / 17, y = 14 + Math.sin(i / 17 * Math.PI) * 10; ctx.fillStyle = fc[i % 4]; ctx.beginPath(); ctx.moveTo(x - 6, y); ctx.lineTo(x + 6, y); ctx.lineTo(x, y + 12); ctx.fill(); }
      // ground
      ctx.fillStyle = '#c9a46a'; ctx.fillRect(0, groundY - H * 0.08, W, H);
      ctx.fillStyle = 'rgba(120,80,40,.12)'; for (let i = 0; i < 90; i++) ctx.fillRect((i * 67) % W, groundY - H * 0.07 + (i * 29) % (H * 0.33), 3, 2);
      // base poles (lying in depth at both ends)
      ctx.strokeStyle = '#7d9a3a'; ctx.lineWidth = 7; ctx.lineCap = 'round';
      [x0 - 6, x1 + 6].forEach(x => { ctx.beginPath(); ctx.moveTo(x - 10, groundY + open * 0.75); ctx.lineTo(x + 6, groundY - open * 0.65); ctx.stroke(); });
    }
    function poleY(f, near) { return groundY + (near ? 1 : -1) * open * 0.5 * f; }
    function drawPole(f, near) {
      const y = poleY(f, near), th = near ? 9 : 7;
      ctx.strokeStyle = near ? '#a8c454' : '#93ae47'; ctx.lineWidth = th; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x0, y - th * 0.25); ctx.lineTo(x1, y - th * 0.25); ctx.stroke();
      ctx.strokeStyle = 'rgba(90,110,30,.6)'; ctx.lineWidth = 2;
      for (let k = 1; k < 6; k++) { const xx = x0 + (x1 - x0) * k / 6; ctx.beginPath(); ctx.moveTo(xx, y - th / 2); ctx.lineTo(xx, y + th / 2); ctx.stroke(); }
    }

    reset();
    api.loop(dt => {
      time += dt;
      let g = gapNow();
      if (running) {
        const prev = Math.floor(cyc);
        cyc += dt / (3 * beat);
        if (Math.floor(cyc) > prev) { score++; beat = Math.max(LV.min[L()], beat * 0.965); hud(); }
        g = gapNow();
        if (g.idx !== lastBeat) { lastBeat = g.idx; word = g.idx < 2 ? t('Cạch!', 'Clack!') : t('Chập!', 'CLAP!'); wordLife = 1; }
        if (jumpT >= 0) { jumpT += dt; if (jumpT >= jumpDur) jumpT = -1; }
        if (g.idx === 2 && g.f < 0.22 && jumpT < 0) {
          running = false; dead = true; root.querySelector('.start').hidden = false;
          api.over({ title: t('Ối! Bị kẹp chân 😵', 'Ouch! Feet caught 😵'), text: t(`Bạn qua được ${score} nhịp tre.`, `You survived ${score} bamboo beats.`), score, passed: score >= LV.goal[L()], restart: start });
        }
      } else if (!dead) { cyc += dt / (3 * 0.8); g = gapNow(); } // idle demo rhythm before starting
      if (dead) deadT += dt;
      wordLife = Math.max(0, wordLife - dt * 2);

      drawScene(g);
      const s = Math.min(W, 640) / 300;
      const ends = f => ({ L: [{ x: x0, y: poleY(f, false) }, { x: x0, y: poleY(f, true) }], R: [{ x: x1, y: poleY(f, false) }, { x: x1, y: poleY(f, true) }] });
      const e = ends(g.f), bob = g.idx === 2 ? Math.sin(Math.PI * g.frac) * 2 : 0;
      drawPole(g.f, false);
      // dancer stands between the poles (feet on ground line)
      const jp = jumpT >= 0 ? jumpT / jumpDur : 0;
      const jh = jp > 0 ? Math.sin(Math.PI * jp) * H * 0.2 : 0;
      ctx.fillStyle = 'rgba(0,0,0,.18)'; ctx.beginPath(); ctx.ellipse(W / 2, groundY + 2, 20 * s - jh / 12, 5 * s, 0, 0, 7); ctx.fill();
      drawDancer(W / 2, groundY - jh, s * 1.15, (cyc * 3) % 1 * 0.5, jp, dead);
      drawPole(g.f, true);
      drawHolder(x0 - 26 * s, groundY + open * 0.62, s, false, e.L[0], e.L[1], bob);
      drawHolder(x1 + 26 * s, groundY + open * 0.62, s, true, e.R[0], e.R[1], bob);
      if (wordLife > 0) {
        const clap = g.idx === 2;
        ctx.globalAlpha = wordLife; ctx.fillStyle = clap ? '#a3271f' : '#5a4630'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.font = `800 ${clap ? 32 : 22}px "Be Vietnam Pro", sans-serif`; ctx.fillText(word, W / 2, H * 0.21); ctx.globalAlpha = 1;
      }
      if (!running && !dead) { ctx.fillStyle = '#5a4630'; ctx.textAlign = 'center'; ctx.font = '700 15px "Be Vietnam Pro", sans-serif'; ctx.fillText(t('Nhảy lên khi tre "Chập!"', 'Jump when the poles "CLAP!"'), W / 2, H * 0.21); }
    });
    hud();
  }
});
