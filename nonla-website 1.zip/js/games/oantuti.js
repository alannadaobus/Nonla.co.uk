// Oẳn Tù Tì – Rock Paper Scissors
Core.register({
  id: 'rps', icon: '✊',
  name: { vi: 'Oẳn Tù Tì', en: 'Rock Paper Scissors' },
  tag: { vi: 'Búa – Kéo – Bao', en: 'Rock – Scissors – Paper' },
  rules: {
    vi: '"Oẳn tù tì, ra cái gì, ra cái này!" — Búa thắng Kéo, Kéo thắng Bao, Bao thắng Búa. Ai thắng 3 ván trước là thắng.',
    en: '"Oẳn tù tì, ra cái gì, ra cái này!" — Rock beats scissors, scissors beat paper, paper beats rock. First to 3 wins.'
  },
  fmtBest: (v, t) => v + t(' trận thắng liên tiếp', ' match win streak'),
  mount(root, api) {
    const t = api.t;
    const E = ['✊', '✌️', '✋'], N = [t('Búa', 'Rock'), t('Kéo', 'Scissors'), t('Bao', 'Paper')];
    root.innerHTML = `
      <div class="scores" style="max-width:300px"><span>${t('Bạn', 'You')}: <b class="me">0</b></span><span>${t('Máy', 'CPU')}: <b class="cpu">0</b></span></div>
      <div class="rps-arena"><small>${t('Chọn đi!', 'Choose!')}</small></div>
      <div class="status"></div>
      <div class="rps-choices">${E.map((e, i) => `<button data-c="${i}">${e}<span>${N[i]}</span></button>`).join('')}</div>`;
    const arena = root.querySelector('.rps-arena'), st = root.querySelector('.status');
    let me = 0, cpu = 0, busy = false, streak = 0;
    function reset() { me = cpu = 0; root.querySelector('.me').textContent = 0; root.querySelector('.cpu').textContent = 0; st.textContent = ''; arena.innerHTML = `<small>${t('Chọn đi!', 'Choose!')}</small>`; api.hideOver(); }
    root.querySelectorAll('.rps-choices button').forEach(b => b.onclick = async () => {
      if (busy || me >= 3 || cpu >= 3) return; busy = true;
      for (const w of ['Oẳn', 'tù', 'tì!']) { arena.innerHTML = `<small>${w}</small>`; await api.sleep(280); if (!api.alive()) return; }
      const p = +b.dataset.c, c = Math.floor(Math.random() * 3);
      arena.innerHTML = `<span>${E[p]}</span><small>vs</small><span>${E[c]}</span>`;
      const r = (p - c + 3) % 3;
      if (r === 0) st.textContent = t(`Hoà! Cả hai ra ${N[p]}.`, `Draw! Both chose ${N[p]}.`);
      else if (r === 2) { me++; st.textContent = t(`🎉 Bạn thắng! ${N[p]} thắng ${N[c]}.`, `🎉 You win! ${N[p]} beats ${N[c]}.`); }
      else { cpu++; st.textContent = t(`😅 Máy thắng! ${N[c]} thắng ${N[p]}.`, `😅 CPU wins! ${N[c]} beats ${N[p]}.`); }
      root.querySelector('.me').textContent = me; root.querySelector('.cpu').textContent = cpu;
      busy = false;
      if (me >= 3 || cpu >= 3) {
        streak = me >= 3 ? streak + 1 : 0;
        api.over({ title: me >= 3 ? t('Bạn thắng trận! 🏆', 'You win the match! 🏆') : t('Máy thắng trận!', 'The computer wins the match!'), text: `${me} – ${cpu}` + (streak > 1 ? t(` · Chuỗi thắng: ${streak}`, ` · Win streak: ${streak}`) : ''), score: me >= 3 ? streak : undefined, restart: reset });
      }
    });
  }
});
