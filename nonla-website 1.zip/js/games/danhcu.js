// =====================================================================
// ĐÁNH CÙ – Vietnam Spinning Top (web MVP, 2.5D canvas)
// Follows the SRS: wind the rope → aim → pull & release → physics (spin decay,
// gyroscopic stability, wobble, precession, collisions) → scoring.
//
// PHYSICS ASSUMPTIONS (prototype values, NOT measured from real Vietnamese tops):
//  • I3 = 0.4·m·r²  (spin axis),  I1 ≈ m(0.6·rc² + 0.25·r²) about the tip, rc = 0.42·h
//  • Spin decay: dω/dt = −τ_tip/I3 − c_air·ω,  τ_tip = μ_tip·μ_map·m·g·r_tip·(1 + 6·sinθ)
//  • Gyroscopic stability ("sleeping top"): stable if ω > ω_c = 2·√(m·g·rc·I1) / I3.
//    Above ω_c the tilt slowly decays; below ω_c it grows (wobble) until the body hits the ground.
//  • Precession rate Ω_p ≈ m·g·rc / (I3·ω)  (fast-top approximation).
//  • Rope → top energy model: ω0 = (v_rope / r) · η · (1 − e^(−turns/2.5)) · (1 − 0.3·a),
//    η = 0.85 losses, a = throw angle (0 = straight down, 1 = long throw). Part of the pull
//    goes into translation instead of rotation. No energy is injected after release.
//  • Collisions: normal impulse with restitution e = 0.5 (wood) + Coulomb friction impulse
//    between the spinning surfaces (μ_c = 0.35), clamped so friction only dissipates energy.
// =====================================================================
Core.register({
  id: 'danhcu', icon: '🌀',
  name: { vi: 'Đánh Cù', en: 'Spinning Top' },
  tag: { vi: 'Quấn dây, phóng cù', en: 'Wind, throw, spin' },
  rules: {
    vi: '<b>1. Quấn dây:</b> xoay ngón tay vòng tròn quanh con cù (hoặc giữ nút) — càng nhiều vòng, cù càng nhận nhiều năng lượng. <b>2. Phóng cù:</b> chọn góc ném rồi <b>vuốt thật nhanh và thẳng</b> trên sân theo hướng muốn ném. Vuốt nhanh = quay nhanh; vuốt cong = cù rơi nghiêng. <b>3.</b> Cù quay chậm dần, lắc rồi đổ. <b>Quay lâu:</b> cù quay lâu nhất thắng. <b>Đối kháng:</b> ném trúng cù đối thủ để ghi điểm.',
    en: '<b>1. Wind the rope:</b> circle your finger around the top (or hold the button) — more turns store more energy. <b>2. Throw:</b> pick a throw angle, then <b>swipe fast and straight</b> across the field in the direction you want. Faster swipe = faster spin; a curved swipe lands the top tilted. <b>3.</b> The top slows, wobbles and falls. <b>Longest spin:</b> the top spinning longest wins. <b>Battle:</b> hit your opponents’ tops to score.'
  },
  fmtBest: (v, t) => v + t(' điểm', ' pts'),
  mount(root, api) {
    const t = api.t;
    // ---------------- Data (TopData / maps / rules) ----------------
    const G = 9.81, MU_TIP = 0.12, R_TIP = 0.001, C_AIR = 0.008, MU_SLIDE = 0.05, ARENA_R = 0.55, MU_C = 0.35, E_REST = 0.5;
    const TOPS = [
      { id: 's', name: t('Cù nhỏ', 'Small top'), m: 0.08, h: 0.055, r: 0.025, wood: '#c98b4a', desc: t('Dễ quay nhanh, va chạm yếu', 'Spins fast easily, weak in collisions') },
      { id: 'm', name: t('Cù vừa', 'Medium top'), m: 0.15, h: 0.075, r: 0.035, wood: '#a86b32', desc: t('Cân bằng, ổn định cao', 'Balanced and stable') },
      { id: 'l', name: t('Cù lớn', 'Large top'), m: 0.25, h: 0.095, r: 0.045, wood: '#7f4e22', desc: t('Cần ném mạnh, va chạm mạnh, quay lâu', 'Needs a strong throw; hits hard, spins long') },
    ].map(s => {
      const rc = 0.42 * s.h, I3 = 0.4 * s.m * s.r * s.r, I1 = s.m * (0.6 * rc * rc + 0.25 * s.r * s.r);
      return { ...s, rc, I3, I1, wc: 2 * Math.sqrt(s.m * G * rc * I1) / I3 };
    });
    const MAPS = [
      { id: 'dinh', name: t('Sân đình (gạch)', 'Temple yard (brick)'), mu: 1.0, slide: 1.0, base: '#b9674c', line: 'rgba(255,235,210,.35)' },
      { id: 'dat', name: t('Sân đất quê', 'Village earth yard'), mu: 1.35, slide: 1.3, base: '#a9804f', line: 'rgba(60,40,20,.18)' },
      { id: 'hoi', name: t('Hội làng', 'Village festival'), mu: 1.15, slide: 1.1, base: '#c7a36a', line: 'rgba(120,80,30,.2)' },
    ];
    const COLORS = ['#2f6db3', '#a3271f', '#2f5d3a', '#8a4fb3'];
    const STATE = { READY: t('Sẵn sàng', 'Ready'), AIR: t('Đang bay', 'In the air'), SPIN: t('Quay ổn định', 'Spinning'), WOBBLE: t('Đang lắc', 'Wobbling'), HIT: t('Va chạm', 'Colliding'), FALL: t('Đã đổ', 'Fallen'), OUT: t('Văng khỏi sân', 'Knocked out') };

    const cfg = { mode: 'survival', top: 1, map: 0, opp: 1, level: 'normal' };

    // ---------------- DOM ----------------
    root.innerHTML = `
      <div class="dcu-setup">
        <div class="dcu-row"><b>${t('Chế độ', 'Mode')}</b><div class="seg" data-k="mode">
          <button data-v="training">${t('Luyện tập', 'Training')}</button><button data-v="survival">${t('Quay lâu', 'Longest spin')}</button><button data-v="battle">${t('Đối kháng', 'Battle')}</button></div></div>
        <div class="dcu-row"><b>${t('Chọn cù', 'Choose top')}</b><div class="seg tops" data-k="top">${TOPS.map((s, i) => `<button data-v="${i}"><span class="mini-top" style="--w:${14 + i * 5}px;--c:${s.wood}"></span>${s.name}<small>${s.desc}</small></button>`).join('')}</div></div>
        <div class="dcu-row"><b>${t('Sân chơi', 'Field')}</b><div class="seg" data-k="map">${MAPS.map((m, i) => `<button data-v="${i}">${m.name}</button>`).join('')}</div></div>
        <div class="dcu-row vs"><b>${t('Đối thủ máy', 'AI opponents')}</b><div class="seg" data-k="opp"><button data-v="1">1</button><button data-v="2">2</button><button data-v="3">3</button></div></div>
        <div class="dcu-row vs"><b>${t('Độ khó', 'Difficulty')}</b><div class="seg" data-k="level">
          <button data-v="easy">${t('Dễ', 'Easy')}</button><button data-v="normal">${t('Vừa', 'Normal')}</button><button data-v="hard">${t('Khó', 'Hard')}</button><button data-v="expert">${t('Cao thủ', 'Expert')}</button></div></div>
        <div style="text-align:center;margin-top:10px"><button class="btn go">▶ ${t('Vào trận', 'Start match')}</button></div>
      </div>
      <div class="dcu-game" hidden>
        <div class="hud"><span class="phase"></span><span class="timer"></span></div>
        <div class="cvw"></div>
        <div class="dcu-help status"></div>
        <div class="dcu-ctrl wind-ctrl">
          <div class="meter"><i class="fill"></i><span class="turns"></span></div>
          <div class="btn-line"><button class="tap-btn blue hold">🌀 ${t('Giữ để quấn', 'Hold to wind')}</button><button class="tap-btn green done">${t('Xong → Ném', 'Done → Throw')}</button></div>
        </div>
        <div class="dcu-ctrl aim-ctrl">
          <label class="angle">${t('Góc ném', 'Throw angle')}: <span>${t('Thẳng đứng', 'Straight down')}</span>
            <input type="range" min="0" max="100" value="25"><span>${t('Ném xa', 'Long throw')}</span></label>
        </div>
        <div class="dcu-list"></div>
        <div class="dcu-debug"></div>
        <div style="text-align:center;margin-top:8px"><button class="btn small outline setup">⚙ ${t('Đổi cù / sân / chế độ', 'Change top / field / mode')}</button></div>
      </div>`;
    const $ = s => root.querySelector(s);
    const setupEl = $('.dcu-setup'), gameEl = $('.dcu-game');

    function syncSeg() {
      root.querySelectorAll('.seg').forEach(seg => seg.querySelectorAll('button').forEach(b => b.classList.toggle('active', String(cfg[seg.dataset.k]) === b.dataset.v)));
      root.querySelectorAll('.dcu-row.vs').forEach(r => r.hidden = cfg.mode === 'training');
    }
    root.querySelectorAll('.seg').forEach(seg => seg.querySelectorAll('button').forEach(b => b.onclick = () => {
      const k = seg.dataset.k; cfg[k] = ['top', 'map', 'opp'].includes(k) ? +b.dataset.v : b.dataset.v; syncSeg();
    }));
    syncSeg();

    // ---------------- Canvas & projection ----------------
    gameEl.hidden = false;
    const { cv, ctx, W, H, pos } = api.canvas($('.cvw'), 0.85);
    gameEl.hidden = true;
    const S = (W * 0.45) / ARENA_R, CX = W / 2, CY = H * 0.54, SQ = 0.55, VIS = 1.7; // VIS: draw tops bigger than scale for readability
    const toScreen = (x, y) => ({ x: CX + x * S, y: CY + y * S * SQ });
    const toWorld = (sx, sy) => ({ x: (sx - CX) / S, y: (sy - CY) / (S * SQ) });

    // ---------------- Match state ----------------
    let phase = 'setup', tops = [], me = null, winding = null, flick = null, aimTimer = 0, endT = 0, ended = false, lastThrow = null, holdWind = false, matchT = 0;

    function makeTop(i, specIdx, isAI) {
      const spots = [[0, 0.85], [0, -0.85], [-0.85, 0], [0.85, 0]];
      const sp = spots[i];
      return {
        i, spec: TOPS[specIdx], ai: isAI, color: COLORS[i],
        label: i === 0 ? t('Bạn', 'You') : t(`Máy ${i}`, `CPU ${i}`),
        sx: sp[0] * ARENA_R, sy: sp[1] * ARENA_R, x: sp[0] * ARENA_R, y: sp[1] * ARENA_R,
        vx: 0, vy: 0, w: 0, tx: 0, ty: 0, psi: 0, nut: 0, t: 0, state: 'READY',
        hits: 0, knocks: 0, lastHitBy: null, lastHitAt: -9, hitFlash: 0, air: null, w0: 0,
      };
    }

    // ---------------- Physics (Physics layer) ----------------
    function launch(tp, p) {
      const s = tp.spec;
      const eff = 0.85 * (1 - Math.exp(-p.turns / 2.5));
      tp.w = tp.w0 = (p.v / s.r) * eff * (1 - 0.3 * p.a);
      const tilt = 0.04 + 0.3 * p.a + (1 - p.straight) * 0.9 + Math.random() * 0.03;
      const ta = Math.random() * Math.PI * 2; tp.tx = Math.cos(ta) * tilt; tp.ty = Math.sin(ta) * tilt;
      const dist = 0.1 + 0.32 * p.a * (p.v / 7) + 0.05 * (p.v / 7);
      const lx = tp.sx + p.dir.x * dist, ly = tp.sy + p.dir.y * dist;
      const planar = 0.04 + p.v * 0.07 * p.a;
      tp.air = { fx: tp.sx, fy: tp.sy, lx, ly, k: 0, dur: 0.35, vx: p.dir.x * planar, vy: p.dir.y * planar };
      tp.state = 'AIR'; tp.t = 0; tp.throwP = p;
      if (tp === me) lastThrow = { ...p, w0: tp.w0, tilt };
    }
    function land(tp) {
      const a = tp.air; tp.x = a.lx; tp.y = a.ly; tp.vx = a.vx; tp.vy = a.vy; tp.air = null; tp.state = 'SPIN';
      if (Math.hypot(tp.x, tp.y) > ARENA_R) stop(tp, 'OUT');
      if (Math.hypot(tp.tx, tp.ty) > 1.0) stop(tp, 'FALL');
    }
    function stop(tp, why) {
      if (tp.state === 'FALL' || tp.state === 'OUT') return;
      tp.state = why; tp.w = 0;
      if (tp.lastHitBy && matchT - tp.lastHitAt < 3) { tp.lastHitBy.knocks++; }
    }
    const spinning = tp => tp.state === 'SPIN' || tp.state === 'WOBBLE' || tp.state === 'HIT';
    function stepTop(tp, dt, map) {
      if (!spinning(tp)) return;
      const s = tp.spec, th = Math.hypot(tp.tx, tp.ty);
      const tau = MU_TIP * map.mu * s.m * G * R_TIP * (1 + 6 * Math.sin(th));
      tp.w -= (tau / s.I3 + C_AIR * tp.w) * dt;
      if (tp.w <= 6) { stop(tp, 'FALL'); return; }
      const ratio = tp.w / s.wc;
      const dth = ratio > 1 ? -0.35 * th * Math.min(1, ratio - 1) : 0.5 * (1 / ratio - 1) + 0.35 * th;
      const nth = Math.max(0, th + dth * dt);
      let ph = th > 1e-4 ? Math.atan2(tp.ty, tp.tx) : Math.random() * 6.283;
      ph += Math.min(25, s.m * G * s.rc / (s.I3 * tp.w)) * dt; // precession
      tp.tx = nth * Math.cos(ph); tp.ty = nth * Math.sin(ph);
      const sp = Math.hypot(tp.vx, tp.vy);
      if (sp > 0) { const ns = Math.max(0, sp - MU_SLIDE * map.slide * G * (1 + 2 * nth) * dt); tp.vx *= ns / sp; tp.vy *= ns / sp; }
      const drift = tp.w * 0.0025 * Math.sin(nth); // tip rolling on a tilted top → circular path
      tp.x += (tp.vx - Math.sin(ph) * drift) * dt; tp.y += (tp.vy + Math.cos(ph) * drift) * dt;
      tp.psi += Math.min(tp.w, 28) * dt; tp.nut += dt * (9 + tp.w * 0.08); tp.t += dt;
      tp.hitFlash = Math.max(0, tp.hitFlash - dt);
      tp.state = tp.hitFlash > 0 ? 'HIT' : (ratio < 1 || nth > 0.25 ? 'WOBBLE' : 'SPIN');
      if (nth > 1.0) stop(tp, 'FALL');
      else if (Math.hypot(tp.x, tp.y) > ARENA_R) stop(tp, 'OUT');
    }
    function collide(a, b) {
      if (!spinning(a) || !spinning(b)) return;
      const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy), rr = a.spec.r + b.spec.r;
      if (d >= rr || d === 0) return;
      const nx = dx / d, ny = dy / d, tx = -ny, ty = nx, ma = a.spec.m, mb = b.spec.m;
      const over = rr - d; a.x -= nx * over * mb / (ma + mb); a.y -= ny * over * mb / (ma + mb); b.x += nx * over * ma / (ma + mb); b.y += ny * over * ma / (ma + mb);
      const vn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
      const Jn = Math.max(0, -(1 + E_REST) * vn / (1 / ma + 1 / mb)) + 0.004; // small preload: spinning bodies grind on contact
      a.vx -= Jn * nx / ma; a.vy -= Jn * ny / ma; b.vx += Jn * nx / mb; b.vy += Jn * ny / mb;
      const ut = a.w * a.spec.r + b.w * b.spec.r + (a.vx - b.vx) * tx + (a.vy - b.vy) * ty;
      if (ut > 0) {
        const lim = ut / (a.spec.r ** 2 / a.spec.I3 + b.spec.r ** 2 / b.spec.I3 + 1 / ma + 1 / mb);
        const Jt = Math.min(MU_C * Jn, lim);
        a.w -= Jt * a.spec.r / a.spec.I3; b.w -= Jt * b.spec.r / b.spec.I3;
        a.vx -= Jt * tx / ma; a.vy -= Jt * ty / ma; b.vx += Jt * tx / mb; b.vy += Jt * ty / mb;
      }
      const ka = Jn / ma * 0.7, kb = Jn / mb * 0.7;
      a.tx -= nx * ka; a.ty -= ny * ka; b.tx += nx * kb; b.ty += ny * kb;
      if (Jn > 0.012) {
        const sa = a.vx * nx + a.vy * ny, sb = -(b.vx * nx + b.vy * ny); // who came in faster gets the hit
        const atk = Math.abs(vn) > 0.05 ? (sa >= sb ? a : b) : null;
        if (atk && a.hitFlash <= 0 && b.hitFlash <= 0) { atk.hits++; const vic = atk === a ? b : a; vic.lastHitBy = atk; vic.lastHitAt = matchT; }
        a.hitFlash = b.hitFlash = 0.2;
      }
    }

    // ---------------- AI (same physics, no advantages) ----------------
    function aiThrow(tp) {
      const L = { easy: [0.5, 3, 5, 3, 4.6, 0.6, 0.85], normal: [0.2, 5, 7, 4.5, 5.8, 0.85, 0.95], hard: [0.1, 6, 8, 5.2, 6.5, 0.9, 0.97], expert: [0.05, 7, 8, 6, 6.9, 0.94, 0.99] }[cfg.level];
      const rnd = (a, b) => a + Math.random() * (b - a);
      let target = { x: 0, y: 0 };
      if (cfg.mode === 'battle' && me && (spinning(me) || me.air)) {
        const p = me.air ? { x: me.air.lx, y: me.air.ly } : me;
        target = cfg.level === 'expert' || cfg.level === 'hard' ? { x: p.x + me.vx * 0.3, y: p.y + me.vy * 0.3 } : p;
      }
      const base = Math.atan2(target.y - tp.sy, target.x - tp.sx) + rnd(-L[0], L[0]);
      const dir = { x: Math.cos(base), y: Math.sin(base) };
      const dist = Math.hypot(target.x - tp.sx, target.y - tp.sy);
      let p = { turns: rnd(L[1], L[2]), v: rnd(L[3], L[4]), straight: rnd(L[5], L[6]), dir, a: (cfg.mode === 'battle' && (target.x || target.y)) ? Math.min(0.8, Math.max(0.1, (dist - 0.15) / 0.45)) : rnd(0.1, cfg.level === 'easy' ? 0.7 : 0.35) };
      if (cfg.level === 'expert' && cfg.mode !== 'battle') { // predictive simulation: pick the throw that spins longest
        let best = -1;
        for (const a of [0.05, 0.12, 0.2, 0.3]) { const q = { ...p, a, straight: 0.97 }; const tsim = simulate(tp.spec, q); if (tsim > best) { best = tsim; p = q; } }
      }
      return p;
    }
    function simulate(spec, p) {
      const s = { ...makeTop(9 % 4, TOPS.indexOf(spec), true), spec };
      s.sx = 0; s.sy = 0.4; launch(s, { ...p, straight: p.straight }); s.tx = s.ty = (0.04 + 0.3 * p.a + (1 - p.straight) * 0.9) / Math.SQRT2;
      s.state = 'SPIN'; s.x = 0; s.y = 0; s.vx = s.vy = 0;
      let T = 0; const map = MAPS[cfg.map];
      while (spinning(s) && T < 120) { stepTop(s, 0.02, map); s.x = s.y = 0; T += 0.02; }
      return T;
    }

    // ---------------- Phases (Gameplay layer) ----------------
    function startMatch() {
      api.hideOver(); ended = false; matchT = 0; endT = 0;
      setupEl.hidden = true; gameEl.hidden = false;
      const n = cfg.mode === 'training' ? 1 : 1 + cfg.opp;
      tops = []; for (let i = 0; i < n; i++) tops.push(makeTop(i, i === 0 ? cfg.top : Math.floor(Math.random() * 3), i > 0));
      me = tops[0];
      winding = { turns: 0, acc: 0, last: null };
      setPhase('wind');
    }
    function setPhase(p) {
      phase = p;
      $('.wind-ctrl').hidden = p !== 'wind';
      $('.aim-ctrl').hidden = p !== 'aim';
      $('.dcu-debug').hidden = cfg.mode !== 'training';
      if (p === 'wind') { $('.phase').textContent = '① ' + t('Quấn dây', 'Wind the rope'); help(t('Xoay ngón tay vòng tròn quanh con cù để quấn dây', 'Circle your finger around the top to wind the rope')); }
      if (p === 'aim') {
        $('.phase').textContent = '② ' + t('Phóng cù', 'Throw');
        help(cfg.mode === 'battle' ? t('Vuốt nhanh về phía cù đối thủ để ném trúng!', 'Swipe fast towards an opponent’s top to hit it!') : t('Vuốt thật nhanh và thẳng trên sân để phóng cù', 'Swipe fast and straight across the field to throw'));
        aimTimer = cfg.mode === 'battle' ? 10 : 0;
        if (cfg.mode === 'battle') tops.filter(x => x.ai).forEach((x, k) => api.timeout(() => launch(x, aiThrow(x)), 300 + k * 400));
      }
      if (p === 'play') { $('.phase').textContent = '③ ' + t('Cù đang quay', 'Spinning'); help(t('Quan sát cù quay, nghiêng và va chạm…', 'Watch the tops spin, tilt and collide…')); }
    }
    function help(s) { $('.dcu-help').textContent = s; }

    function playerThrow(p) {
      launch(me, p);
      if (cfg.mode === 'survival') tops.filter(x => x.ai).forEach(x => api.timeout(() => launch(x, aiThrow(x)), 150 + Math.random() * 450));
      setPhase('play');
    }

    // winding input
    const meter = () => { const f = Math.min(1, winding.turns / 8); $('.fill').style.width = f * 100 + '%'; $('.turns').textContent = t(`Vòng dây: ${winding.turns.toFixed(1)} / 8`, `Rope turns: ${winding.turns.toFixed(1)} / 8`); };
    api.on($('.hold'), 'pointerdown', e => { e.preventDefault(); holdWind = true; });
    api.on(window, 'pointerup', () => { holdWind = false; });
    $('.done').onclick = () => { if (phase === 'wind') setPhase('aim'); };

    api.on(cv, 'pointerdown', e => {
      cv.setPointerCapture && cv.setPointerCapture(e.pointerId);
      const p = pos(e);
      if (phase === 'wind') winding.last = Math.atan2(p.y - H * 0.5, p.x - W / 2);
      if (phase === 'aim') flick = { pts: [{ ...p, t: performance.now() }], len: 0 };
    });
    api.on(cv, 'pointermove', e => {
      const p = pos(e);
      if (phase === 'wind' && winding.last !== null) {
        const a = Math.atan2(p.y - H * 0.5, p.x - W / 2); let da = a - winding.last;
        if (da > Math.PI) da -= 2 * Math.PI; if (da < -Math.PI) da += 2 * Math.PI;
        winding.last = a; winding.turns = Math.min(8, winding.turns + Math.abs(da) / (2 * Math.PI)); meter();
      }
      if (phase === 'aim' && flick) { const l = flick.pts[flick.pts.length - 1]; flick.len += Math.hypot(p.x - l.x, p.y - l.y); flick.pts.push({ ...p, t: performance.now() }); }
    });
    api.on(cv, 'pointerup', () => {
      if (phase === 'wind') winding.last = null;
      if (phase !== 'aim' || !flick) return;
      const pts = flick.pts, a = pts[0], b = pts[pts.length - 1];
      const chord = Math.hypot(b.x - a.x, b.y - a.y);
      if (chord < 30) { flick = null; return; }
      const now = b.t; let k = pts.length - 1; while (k > 0 && now - pts[k].t < 90) k--;
      const sp = Math.hypot(b.x - pts[k].x, b.y - pts[k].y) / Math.max(0.016, (now - pts[k].t) / 1000);
      const v = Math.min(7, sp / W);
      const wd = { x: (b.x - a.x) / S, y: (b.y - a.y) / (S * SQ) }, wl = Math.hypot(wd.x, wd.y);
      const straight = Math.max(0.5, Math.min(1, chord / Math.max(chord, flick.len)));
      flick = null;
      playerThrow({ turns: winding.turns, v, straight, a: +root.querySelector('.angle input').value / 100, dir: { x: wd.x / wl, y: wd.y / wl } });
    });

    $('.go').onclick = startMatch;
    $('.setup').onclick = () => { phase = 'setup'; tops = []; api.hideOver(); setupEl.hidden = false; gameEl.hidden = true; };

    // ---------------- Scoring (SRS table) ----------------
    function finish() {
      ended = true;
      const rank = [...tops].sort((x, y) => y.t - x.t);
      const winner = cfg.mode === 'training' ? null : rank[0];
      const pts = tp => (tp.t > 30 ? 30 : tp.t > 20 ? 20 : tp.t > 10 ? 10 : 0) + tp.hits * 10 + tp.knocks * 20 + (tp === winner ? 50 : 0);
      if (cfg.mode === 'battle') { tops.forEach(x => x.pts = pts(x)); rank.sort((x, y) => y.pts - x.pts); }
      const fmt = x => `${x.label}: ${x.t.toFixed(1)}s` + (cfg.mode === 'battle' ? ` · ${x.hits} ${t('lần trúng', 'hits')} · ${pts(x)} ${t('điểm', 'pts')}` : '');
      if (cfg.mode === 'training') {
        const L = lastThrow || {};
        api.over({
          title: t(`Cù quay ${me.t.toFixed(1)} giây`, `Your top spun for ${me.t.toFixed(1)}s`),
          text: t(`Vòng dây ${(L.turns || 0).toFixed(1)} · Tốc độ kéo ${(L.v || 0).toFixed(1)} m/s · Độ thẳng ${Math.round((L.straight || 0) * 100)}% · Góc ${Math.round((L.a || 0) * 100)}% · ω₀ ${Math.round((L.w0 || 0) * 60 / 2 / Math.PI)} vòng/phút`,
            `Turns ${(L.turns || 0).toFixed(1)} · Pull speed ${(L.v || 0).toFixed(1)} m/s · Straightness ${Math.round((L.straight || 0) * 100)}% · Angle ${Math.round((L.a || 0) * 100)}% · ω₀ ${Math.round((L.w0 || 0) * 60 / 2 / Math.PI)} rpm`),
          score: pts(me), restart: startMatch
        });
        return;
      }
      const top1 = cfg.mode === 'battle' ? rank[0] : winner;
      api.over({
        title: top1 === me ? t('Bạn thắng! 🏆', 'You win! 🏆') : t(`${top1.label} thắng!`, `${top1.label} wins!`),
        text: rank.map(fmt).join('<br>') + `<br><b>${t('Điểm của bạn', 'Your score')}: ${pts(me)}</b>`,
        score: pts(me), restart: startMatch
      });
    }

    // ---------------- Rendering (Presentation layer) ----------------
    function drawField(map) {
      ctx.fillStyle = map.id === 'hoi' ? '#e9d7a8' : '#cfe0b4'; ctx.fillRect(0, 0, W, H);
      if (map.id === 'dinh') { ctx.fillStyle = '#8a5a3a'; ctx.fillRect(0, 0, W, H * 0.16); ctx.fillStyle = '#5b3a24'; ctx.beginPath(); ctx.moveTo(W * 0.1, H * 0.16); ctx.lineTo(W * 0.5, H * 0.03); ctx.lineTo(W * 0.9, H * 0.16); ctx.fill(); }
      if (map.id === 'dat') { ctx.fillStyle = '#6f9a4b'; for (let i = 0; i < 14; i++) { ctx.fillRect(i * W / 13, 0, 5, H * 0.18); ctx.beginPath(); ctx.arc(i * W / 13 + 2, H * 0.03, 10, 0, 7); ctx.fill(); } }
      if (map.id === 'hoi') { const fc = ['#a3271f', '#e6a700', '#2f6db3', '#2f5d3a']; ctx.strokeStyle = '#7a5a33'; ctx.beginPath(); ctx.moveTo(0, 18); ctx.quadraticCurveTo(W / 2, 40, W, 18); ctx.stroke(); for (let i = 0; i < 16; i++) { const x = i * W / 15, y = 18 + Math.sin(i / 15 * Math.PI) * 11; ctx.fillStyle = fc[i % 4]; ctx.beginPath(); ctx.moveTo(x - 7, y); ctx.lineTo(x + 7, y); ctx.lineTo(x, y + 14); ctx.fill(); } }
      ctx.save(); ctx.beginPath(); ctx.ellipse(CX, CY, ARENA_R * S, ARENA_R * S * SQ, 0, 0, 7); ctx.fillStyle = map.base; ctx.fill(); ctx.clip();
      ctx.strokeStyle = map.line; ctx.lineWidth = 1;
      if (map.id === 'dinh') { for (let y = CY - ARENA_R * S; y < CY + ARENA_R * S; y += 12) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); } for (let x = 0; x < W; x += 22) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); } }
      else { ctx.fillStyle = map.line; for (let i = 0; i < 160; i++) ctx.fillRect((i * 73) % W, (i * 41) % H, 2, 2); }
      ctx.restore();
      ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(CX, CY, ARENA_R * S, ARENA_R * S * SQ, 0, 0, 7); ctx.stroke();
    }
    function drawTop(tp, x, y, scale = 1, lift = 0) {
      const s = tp.spec, th0 = Math.hypot(tp.tx, tp.ty);
      const wob = tp.state === 'WOBBLE' ? 0.06 * Math.sin(tp.nut) : 0;
      const th = Math.min(Math.PI / 2, th0 + wob), ph = th0 > 1e-4 ? Math.atan2(tp.ty, tp.tx) : 0;
      const hp = s.h * S * VIS * scale, rp = s.r * S * VIS * scale;
      const p = toScreen(x, y); p.y -= lift;
      const fallen = tp.state === 'FALL';
      const ux = Math.sin(fallen ? 1.35 : th) * Math.cos(ph), uy = Math.sin(fallen ? 1.35 : th) * Math.sin(ph) * SQ, uz = Math.cos(fallen ? 1.35 : th);
      const hx = p.x + ux * hp, hy = p.y + uy * hp - uz * hp;
      // shadow
      ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(p.x + ux * hp * 0.5 + 3, p.y + lift + 2, rp * 0.9, rp * 0.35, 0, 0, 7); ctx.fill();
      if (tp === me || tp.ai) { ctx.strokeStyle = tp.color; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(p.x, p.y + lift, rp * 1.3, rp * 0.55, 0, 0, 7); ctx.stroke(); }
      // body (pear shape: tip → widest ring → cap)
      const ang = Math.atan2(hy - p.y, hx - p.x) + Math.PI / 2;
      const cxr = Math.cos(ang), syr = Math.sin(ang);
      const midx = p.x + (hx - p.x) * 0.72, midy = p.y + (hy - p.y) * 0.72;
      const g = ctx.createLinearGradient(midx - cxr * rp, midy - syr * rp, midx + cxr * rp, midy + syr * rp);
      g.addColorStop(0, '#f0c98a'); g.addColorStop(0.45, s.wood); g.addColorStop(1, '#3d2410');
      ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(p.x, p.y);
      ctx.quadraticCurveTo(midx - cxr * rp * 1.15, midy - syr * rp * 1.15, hx - cxr * rp, hy - syr * rp);
      ctx.lineTo(hx + cxr * rp, hy + syr * rp);
      ctx.quadraticCurveTo(midx + cxr * rp * 1.15, midy + syr * rp * 1.15, p.x, p.y); ctx.fill();
      // metal tip
      ctx.fillStyle = '#9aa3ab'; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + (hx - p.x) * 0.16 - cxr * 3, p.y + (hy - p.y) * 0.16 - syr * 3); ctx.lineTo(p.x + (hx - p.x) * 0.16 + cxr * 3, p.y + (hy - p.y) * 0.16 + syr * 3); ctx.fill();
      // cap with rotating stripes (motion blur when fast)
      const capRy = rp * Math.max(0.18, 0.5 * Math.abs(uz) + 0.15);
      ctx.save(); ctx.translate(hx, hy); ctx.rotate(ang);
      ctx.fillStyle = '#e9c48a'; ctx.beginPath(); ctx.ellipse(0, 0, rp, capRy, 0, 0, 7); ctx.fill();
      const blur = Math.min(1, tp.w / 60);
      for (let k = 0; k < 3; k++) {
        const a0 = tp.psi + k * 2.094;
        ctx.globalAlpha = 1 - blur * 0.75; ctx.strokeStyle = tp.color; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a0) * rp, Math.sin(a0) * capRy); ctx.stroke();
      }
      ctx.globalAlpha = 0.35 + blur * 0.5; ctx.strokeStyle = tp.color; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.ellipse(0, 0, rp * 0.62, capRy * 0.62, 0, 0, 7); ctx.stroke();
      ctx.globalAlpha = 1; ctx.fillStyle = '#5a3a1e'; ctx.beginPath(); ctx.ellipse(0, 0, 3, 2, 0, 0, 7); ctx.fill();
      ctx.restore();
      if (tp.hitFlash > 0) { ctx.strokeStyle = '#ffd36b'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(hx, hy, rp * 1.6, 0, 7); ctx.stroke(); }
      ctx.fillStyle = '#2a1d14'; ctx.font = '600 11px "Be Vietnam Pro", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText(tp.label, p.x, p.y + lift + rp * 0.6 + 2);
    }
    function drawWinding() {
      ctx.fillStyle = '#fbf3e2'; ctx.fillRect(0, 0, W, H);
      const s = me.spec, cx = W / 2, cy = H * 0.5, hp = H * 0.55 * (s.h / 0.095), rp = hp * (s.r / s.h) * 1.15;
      const tipY = cy + hp / 2, capY = cy - hp / 2;
      ctx.strokeStyle = 'rgba(163,39,31,.15)'; ctx.lineWidth = 2; ctx.setLineDash([6, 8]); ctx.beginPath(); ctx.arc(cx, cy, Math.min(W, H) * 0.42, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      const g = ctx.createLinearGradient(cx - rp, 0, cx + rp, 0); g.addColorStop(0, '#f0c98a'); g.addColorStop(0.45, s.wood); g.addColorStop(1, '#3d2410');
      ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(cx, tipY);
      ctx.quadraticCurveTo(cx - rp * 1.25, capY + hp * 0.35, cx - rp, capY); ctx.lineTo(cx + rp, capY);
      ctx.quadraticCurveTo(cx + rp * 1.25, capY + hp * 0.35, cx, tipY); ctx.fill();
      ctx.fillStyle = '#e9c48a'; ctx.beginPath(); ctx.ellipse(cx, capY, rp, rp * 0.28, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#9aa3ab'; ctx.beginPath(); ctx.moveTo(cx, tipY + 12); ctx.lineTo(cx - 6, tipY - 6); ctx.lineTo(cx + 6, tipY - 6); ctx.fill();
      // rope coils, wound from the tip upward
      const n = winding.turns, bandTop = capY + hp * 0.15, bandBot = tipY - hp * 0.2;
      ctx.strokeStyle = '#efe6cf'; ctx.lineWidth = 4; ctx.lineCap = 'round';
      for (let k = 0; k < Math.floor(n * 2); k++) {
        const y = bandBot - (bandBot - bandTop) * (k / 16);
        const wHalf = rp * (0.35 + 0.65 * (1 - (y - capY) / hp) ** 0.6);
        ctx.beginPath(); ctx.ellipse(cx, y, wHalf, 3.5, 0.08, 0, Math.PI); ctx.stroke();
      }
      if (n > 0) { const y = bandBot - (bandBot - bandTop) * (Math.floor(n * 2) / 16); ctx.beginPath(); ctx.moveTo(cx + rp * 0.6, y); ctx.quadraticCurveTo(W * 0.85, y + 10, W * 0.9, H * 0.2); ctx.stroke(); ctx.font = '30px serif'; ctx.fillStyle = '#000'; ctx.fillText('✊', W * 0.9 - 14, H * 0.2 - 4); }
      ctx.fillStyle = '#2a1d14'; ctx.font = '700 16px "Be Vietnam Pro", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
      ctx.fillText(me.spec.name, cx, H * 0.08);
    }

    // ---------------- Main loop ----------------
    const listEl = $('.dcu-list'), dbgEl = $('.dcu-debug');
    let uiT = 0;
    api.loop(dt => {
      if (phase === 'setup') return;
      const map = MAPS[cfg.map];
      if (phase === 'wind') {
        if (holdWind) { winding.turns = Math.min(8, winding.turns + dt * 1.4); meter(); }
        drawWinding(); return;
      }
      // physics
      const sub = 3, h = dt / sub;
      for (let k = 0; k < sub; k++) {
        matchT += h;
        tops.forEach(tp => { if (tp.state === 'AIR') { tp.air.k += h / tp.air.dur; if (tp.air.k >= 1) land(tp); } else stepTop(tp, h, map); });
        for (let i = 0; i < tops.length; i++) for (let j = i + 1; j < tops.length; j++) collide(tops[i], tops[j]);
      }
      if (phase === 'aim' && aimTimer > 0) {
        aimTimer -= dt; $('.timer').textContent = `⏱ ${Math.ceil(aimTimer)}s`;
        if (aimTimer <= 0) playerThrow({ turns: winding.turns, v: 2.5, straight: 0.7, a: 0.3, dir: { x: 0, y: -1 } });
      } else if (phase === 'play') $('.timer').textContent = `⏱ ${me.t.toFixed(1)}s`;
      if (phase === 'play' && !ended && tops.every(tp => tp.state === 'FALL' || tp.state === 'OUT')) { endT += dt; if (endT > 1) finish(); }
      // draw
      drawField(map);
      const order = [...tops].sort((a, b) => (a.air ? a.air.fy + (a.air.ly - a.air.fy) * a.air.k : a.y) - (b.air ? b.air.fy + (b.air.ly - b.air.fy) * b.air.k : b.y));
      order.forEach(tp => {
        if (tp.state === 'READY') { drawTop(tp, tp.sx, tp.sy, 0.8, 26); return; }
        if (tp.state === 'AIR') { const a = tp.air, k = a.k; drawTop(tp, a.fx + (a.lx - a.fx) * k, a.fy + (a.ly - a.fy) * k, 1, Math.sin(Math.PI * k) * 40 + (1 - k) * 26); return; }
        drawTop(tp, tp.x, tp.y);
      });
      if (phase === 'aim' && flick && flick.pts.length > 1) {
        const a = flick.pts[0], b = flick.pts[flick.pts.length - 1];
        ctx.strokeStyle = '#a3271f'; ctx.lineWidth = 4; ctx.setLineDash([8, 6]); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.setLineDash([]);
      }
      if (phase === 'aim' && !flick) {
        const p = toScreen(me.sx, me.sy);
        ctx.fillStyle = 'rgba(163,39,31,.85)'; ctx.font = '700 14px "Be Vietnam Pro", sans-serif'; ctx.textAlign = 'center';
        ctx.fillText(t('↑ Vuốt để ném', '↑ Swipe to throw'), p.x, p.y - 48);
      }
      // HUD lists (throttled)
      uiT -= dt;
      if (uiT <= 0) {
        uiT = 0.12;
        listEl.innerHTML = tops.map(tp => `<span style="border-color:${tp.color}"><b style="color:${tp.color}">●</b> ${tp.label} · ${tp.spec.name} · ${Math.round(tp.w * 60 / 2 / Math.PI)} ${t('v/ph', 'rpm')} · ${STATE[tp.state] || ''}${tp.t ? ' · ' + tp.t.toFixed(1) + 's' : ''}</span>`).join('');
        if (cfg.mode === 'training' && me) {
          const th = Math.hypot(me.tx, me.ty), s = me.spec;
          dbgEl.innerHTML = `<b>${t('Thông số vật lý', 'Physics debug')}</b><br>ω = ${me.w.toFixed(1)} rad/s (${Math.round(me.w * 60 / 2 / Math.PI)} ${t('vòng/phút', 'rpm')}) · ω<sub>c</sub> = ${s.wc.toFixed(0)} rad/s<br>
            ${t('Góc nghiêng', 'Tilt')} θ = ${(th * 180 / Math.PI).toFixed(1)}° · L = Iω = ${(s.I3 * me.w * 1000).toFixed(2)}×10⁻³ kg·m²/s<br>
            E<sub>quay</sub> = ½Iω² = ${(0.5 * s.I3 * me.w * me.w * 1000).toFixed(1)} mJ · ${t('Trạng thái', 'State')}: ${STATE[me.state]}`;
        }
      }
    });
  }
});
