// Rồng Rắn Lên Mây – Dragon & Snake
Core.register({
  id: 'rongran', icon: '🐉',
  name: { vi: 'Rồng Rắn Lên Mây', en: 'Dragon Snake' },
  tag: { vi: 'Bắt đuôi rồng', en: 'Catch the dragon’s tail' },
  rules: {
    vi: 'Bạn là <b>thầy thuốc</b> 🧑‍⚕️. Kéo ngón tay để di chuyển và chạm vào <b>khúc đuôi</b> (vòng vàng) của con rồng. Đầu rồng 🐲 sẽ chạy ra chắn — đừng đâm vào nó! Bắt hết 5 khúc đuôi trong 45 giây.',
    en: 'You are the <b>healer</b> 🧑‍⚕️. Drag your finger to move and touch the <b>tail</b> (gold ring) of the dragon line. The dragon head 🐲 will try to block you — don’t bump into it! Catch all 5 tail kids within 45 seconds.'
  },
  fmtBest: (v, t) => v + t(' điểm', ' pts'),
  mount(root, api) {
    const t = api.t;
    root.innerHTML = `<div class="goal"></div><div class="hud"><span class="sc"></span><span class="tm"></span></div><div class="cvw"></div>
      <div class="oaq-controls"><button class="btn start">▶ ${t('Bắt đầu', 'Start')}</button></div>`;
    const LV = { head: [100, 115, 128, 140, 152], n: [3, 4, 5, 6, 7], time: [45, 45, 45, 50, 55] }, L = () => api.level() - 1;
    api.levelBar(root, 5, () => { running = false; done = false; reset(); hud(); root.querySelector('.start').hidden = false; api.hideOver(); });
    const { cv, ctx, W, H, pos } = api.canvas(root.querySelector('.cvw'), 0.85);
    const SP = 26, RAD = 15;
    let running = false, player, target, head, segs, caught, timeLeft, msg = null, done = false;

    function reset() {
      player = { x: W / 2, y: H - 40 }; target = { ...player };
      head = { x: W / 2, y: H * 0.35 };
      segs = []; for (let i = 1; i <= LV.n[L()]; i++) segs.push({ x: W / 2, y: H * 0.35 - i * SP });
      caught = 0; timeLeft = LV.time[L()]; msg = null; done = false;
    }
    function hud() {
      root.querySelector('.sc').textContent = `🧒 ${caught}/${LV.n[L()]}`; root.querySelector('.goal').innerHTML = `🎯 ${t('Bắt hết', 'Catch all')} ${LV.n[L()]} ${t('khúc đuôi trong', 'tail kids in')} ${LV.time[L()]}s`;
      root.querySelector('.tm').textContent = `⏱ ${Math.ceil(timeLeft)}s`;
    }
    const setT = e => { if (!running) return; const p = pos(e); target = p; };
    api.on(cv, 'pointerdown', e => { cv.setPointerCapture && cv.setPointerCapture(e.pointerId); setT(e); });
    api.on(cv, 'pointermove', e => { if (e.buttons || e.pointerType === 'mouse') setT(e); });

    function start() { api.hideOver(); reset(); running = true; hud(); root.querySelector('.start').hidden = true; }
    root.querySelector('.start').onclick = start;
    function finish(win) {
      running = false; done = true; root.querySelector('.start').hidden = false;
      const score = caught * 100 + (win ? Math.ceil(timeLeft) * 10 : 0);
      api.over({
        title: win ? t('Bắt được cả đàn rồng! 🎉', 'You caught the whole dragon! 🎉') : t('Hết giờ! ⏰', 'Time’s up! ⏰'),
        text: t(`Bắt được ${caught}/${LV.n[L()]} khúc đuôi · ${score} điểm`, `Caught ${caught}/${LV.n[L()]} tail kids · ${score} points`), score, passed: win, restart: start
      });
    }
    const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
    function moveTo(o, tx, ty, sp, dt) { const dx = tx - o.x, dy = ty - o.y, d = Math.hypot(dx, dy); if (d > 1) { const s = Math.min(d, sp * dt); o.x += dx / d * s; o.y += dy / d * s; } }
    function emoji(ch, x, y, s) { ctx.fillStyle = '#000'; ctx.font = `${s}px serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(ch, x, y); }
    reset();

    api.loop(dt => {
      if (running) {
        timeLeft -= dt; hud();
        moveTo(player, target.x, target.y, 165, dt);
        player.x = clamp(player.x, RAD, W - RAD); player.y = clamp(player.y, RAD, H - RAD);
        const tail = segs[segs.length - 1];
        // head blocks: stand between the tail and the player
        let dx = player.x - tail.x, dy = player.y - tail.y, d = Math.hypot(dx, dy) || 1;
        const guard = Math.min(60 + segs.length * 6, d * 0.8);
        moveTo(head, clamp(tail.x + dx / d * guard, RAD, W - RAD), clamp(tail.y + dy / d * guard, RAD, H - RAD), LV.head[L()] + caught * 10, dt);
        // body follows the leader
        segs.forEach((s, i) => { const p = i === 0 ? head : segs[i - 1]; const ex = s.x - p.x, ey = s.y - p.y, dd = Math.hypot(ex, ey) || 1; if (dd > SP) { s.x = p.x + ex / dd * SP; s.y = p.y + ey / dd * SP; } });
        // bump into head/body → pushed away
        [head, ...segs.slice(0, -1)].forEach(o => { const ex = player.x - o.x, ey = player.y - o.y, dd = Math.hypot(ex, ey) || 1; if (dd < RAD * 2) { player.x = o.x + ex / dd * RAD * 2.4; player.y = o.y + ey / dd * RAD * 2.4; } });
        // catch the tail
        if (Math.hypot(player.x - tail.x, player.y - tail.y) < RAD * 1.8) {
          segs.pop(); caught++; hud();
          msg = { txt: t('Bắt được! 🎉', 'Got one! 🎉'), life: 1 };
          player.y = player.y < H / 2 ? H - 40 : 40; player.x = W / 2; target = { ...player };
          if (!segs.length) finish(true);
        }
        if (timeLeft <= 0 && running) { timeLeft = 0; hud(); finish(false); }
      }
      // draw
      ctx.fillStyle = '#e8f3d6'; ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = 'rgba(47,93,58,.12)'; ctx.lineWidth = 1;
      for (let x = 0; x < W; x += 30) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
      ctx.strokeStyle = '#a3271f'; ctx.lineWidth = 3; ctx.beginPath();
      ctx.moveTo(head.x, head.y); segs.forEach(s => ctx.lineTo(s.x, s.y)); ctx.stroke();
      segs.forEach((s, i) => {
        if (i === segs.length - 1) { ctx.strokeStyle = '#e6a700'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(s.x, s.y, RAD + 4, 0, Math.PI * 2); ctx.stroke(); }
        emoji(i % 2 ? '👧' : '🧒', s.x, s.y, 26);
      });
      emoji('🐲', head.x, head.y, 34);
      if (segs.length || done) emoji(done && !segs.length ? '🥳' : '🧑‍⚕️', player.x, player.y, 32);
      if (msg && msg.life > 0) { msg.life -= dt; ctx.globalAlpha = Math.max(0, msg.life); ctx.fillStyle = '#a3271f'; ctx.font = '800 24px "Be Vietnam Pro", sans-serif'; ctx.fillText(msg.txt, W / 2, 34); ctx.globalAlpha = 1; }
      if (!running && !done) {
        ctx.fillStyle = 'rgba(255,250,240,.85)'; ctx.fillRect(0, H / 2 - 40, W, 80);
        ctx.fillStyle = '#2a1d14'; ctx.font = 'italic 600 16px "Be Vietnam Pro", sans-serif';
        ctx.fillText(t('"Rồng rắn lên mây, có cây núc nắc..."', '"Dragon, snake, up to the clouds..."'), W / 2, H / 2 - 10);
        ctx.font = '14px "Be Vietnam Pro", sans-serif'; ctx.fillText(t('Kéo ngón tay để chạy', 'Drag your finger to run'), W / 2, H / 2 + 16);
      }
    });
    hud();
  }
});
