// Kéo Co – Tug of War
Core.register({
  id: 'keoco', icon: '🪢',
  name: { vi: 'Kéo Co', en: 'Tug of War' },
  tag: { vi: 'Bấm thật nhanh!', en: 'Tap as fast as you can!' },
  rules: {
    vi: 'Bấm nút <b>KÉO!</b> thật nhanh để kéo dải ruy băng đỏ về phía đội bạn. Kéo qua vạch đỏ là thắng. Có thể chơi 2 người trên cùng một điện thoại.',
    en: 'Tap <b>PULL!</b> as fast as you can to drag the red ribbon to your side. Pull it past the red line to win. Two players can share one phone.'
  },
  fmtBest: v => v.toFixed(1) + 's',
  mount(root, api) {
    const t = api.t;
    root.innerHTML = `
      <div class="opt-row">
        <label><input type="radio" name="tugMode" value="cpu" checked> ${t('Đấu với máy', 'vs Computer')}</label>
        <label><input type="radio" name="tugMode" value="2p"> ${t('2 người', '2 players')}</label>

      </div>
      <div class="tug-field">
        <div class="tug-zone" style="left:22%"></div><div class="tug-center"></div><div class="tug-zone" style="left:78%"></div>
        <div class="tug-rope"><span class="team l">🧍🧍🧍</span><span class="rope-line"><i class="ribbon"></i></span><span class="team r">🧍🧍🧍</span></div>
      </div>
      <div class="hud" style="margin-top:6px"><span class="nl"></span><span class="nr"></span></div>
      <div class="status">${t('Bấm Bắt đầu', 'Press Start')}</div>
      <div class="btn-line">
        <button class="tap-btn blue p1">${t('KÉO!', 'PULL!')}</button>
        <button class="tap-btn red p2" hidden>${t('KÉO!', 'PULL!')}</button>
      </div>
      <div class="oaq-controls"><button class="btn start">▶ ${t('Bắt đầu', 'Start')}</button></div>`;
    const RATE = [4.5, 6, 7.3, 8.6, 10];
    api.levelBar(root, 5, () => { running = false; root.querySelector('.start').hidden = false; pos = 0; draw(); api.hideOver(); });
    const $ = s => root.querySelector(s);
    const rope = $('.tug-rope'), statusEl = $('.status');
    let pos = 0, running = false, cpuTimer = null, startAt = 0;
    const mode = () => root.querySelector('input[name=tugMode]:checked').value;

    function labels() {
      const cpu = mode() === 'cpu';
      $('.p2').hidden = cpu; root.querySelector('.lvl-bar').hidden = !cpu;
      $('.nl').textContent = '🔵 ' + (cpu ? t('Đội bạn', 'Your team') : t('Người 1', 'Player 1'));
      $('.nr').textContent = (cpu ? t('Máy', 'CPU') : t('Người 2', 'Player 2')) + ' 🔴';
    }
    function draw() { rope.style.transform = `translateX(${pos * 0.28}%)`; }
    function pull(dir) {
      if (!running) return;
      pos += dir * 3.2; draw();
      if (pos <= -100) end(1); else if (pos >= 100) end(2);
    }
    function end(winner) {
      running = false; $('.start').hidden = false; if (cpuTimer) api.clear(cpuTimer);
      const secs = (performance.now() - startAt) / 1000;
      const cpu = mode() === 'cpu';
      const title = cpu ? (winner === 1 ? t('Đội bạn thắng! 💪', 'Your team wins! 💪') : t('Máy thắng rồi 😅', 'The computer wins 😅'))
        : (winner === 1 ? t('Người 1 thắng!', 'Player 1 wins!') : t('Người 2 thắng!', 'Player 2 wins!'));
      statusEl.textContent = title;
      api.over({ title, text: t(`Thời gian: ${secs.toFixed(1)} giây`, `Time: ${secs.toFixed(1)}s`), score: cpu && winner === 1 ? secs : undefined, lowerIsBetter: true, passed: cpu ? winner === 1 : undefined, restart: start });
    }
    async function start() {
      api.hideOver(); running = false; pos = 0; draw(); labels();
      $('.start').hidden = true;
      for (const c of ['3', '2', '1']) { statusEl.textContent = c; await api.sleep(600); if (!api.alive()) return; }
      statusEl.textContent = t('KÉO!!!', 'PULL!!!');
      running = true; startAt = performance.now();
      if (mode() === 'cpu') {
        const rate = RATE[api.level() - 1];
        const tick = () => { if (!running) return; pull(1); cpuTimer = api.timeout(tick, 1000 / rate * (0.6 + Math.random() * 0.8)); };
        cpuTimer = api.timeout(tick, 300);
      }
    }
    api.on($('.p1'), 'pointerdown', e => { e.preventDefault(); pull(-1); });
    api.on($('.p2'), 'pointerdown', e => { e.preventDefault(); pull(1); });
    $('.start').onclick = start;
    root.querySelectorAll('input[name=tugMode]').forEach(r => r.onchange = () => { running = false; $('.start').hidden = false; pos = 0; draw(); labels(); statusEl.textContent = t('Bấm Bắt đầu', 'Press Start'); });
    labels(); draw();
  }
});
