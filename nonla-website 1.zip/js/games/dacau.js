// Đá Cầu – Shuttlecock Kicking
Core.register({
  id: 'dacau', icon: '🪶',
  name: { vi: 'Đá Cầu', en: 'Shuttlecock Kick' },
  tag: { vi: 'Tâng cầu không cho rơi', en: 'Keep it in the air' },
  rules: {
    vi: 'Chạm vào quả cầu để đá nó bay lên. Đừng để cầu rơi xuống đất! Cầu sẽ rơi nhanh dần.',
    en: 'Tap the shuttlecock to kick it back up. Don’t let it touch the ground! It falls faster as you go.'
  },
  fmtBest: (v, t) => v + t(' lần', ' kicks'),
  mount(root, api) {
    const t = api.t;
    root.innerHTML = `<div class="goal"></div><div class="hud"><span class="sc"></span><span></span></div><div class="cvw"></div>
      <div class="oaq-controls"><button class="btn start">▶ ${t('Bắt đầu', 'Start')}</button></div>`;
    const LV = { g: [420, 500, 580, 660, 740], wind: [0, 0, 40, 70, 100], goal: [10, 15, 20, 25, 30] }, L = () => api.level() - 1;
    api.levelBar(root, 5, () => { running = false; dead = false; reset(); hud(); root.querySelector('.start').hidden = false; api.hideOver(); });
    const { cv, ctx, W, H, pos } = api.canvas(root.querySelector('.cvw'), 1.0);
    const groundY = H - 34;
    let running = false, c, score, g, foot = null, dead = false, wind = 0, windT = 0;

    function reset() { c = { x: W / 2, y: H * 0.25, vx: 0, vy: 0 }; score = 0; g = LV.g[L()]; foot = null; dead = false; windT = 0; wind = 0; }
    function hud() { root.querySelector('.sc').textContent = `🪶 ${score}`; root.querySelector('.goal').innerHTML = `🎯 ${t('Mục tiêu', 'Goal')}: ${LV.goal[L()]} ${t('lần tâng', 'kicks')}${LV.wind[L()] ? ' · 🌬 ' + t('có gió', 'windy') : ''}${score >= LV.goal[L()] ? ' ✅' : ''}`; }
    function start() { api.hideOver(); reset(); running = true; hud(); root.querySelector('.start').hidden = true; }
    root.querySelector('.start').onclick = start;

    api.on(cv, 'pointerdown', e => {
      e.preventDefault();
      if (!running) return;
      const p = pos(e);
      if (Math.hypot(p.x - c.x, p.y - c.y) < 58) {
        const h = H * (0.42 + Math.random() * 0.18);
        c.vy = -Math.sqrt(2 * g * h);
        c.vx = (W / 2 - c.x) * 0.6 + (Math.random() * 160 - 80);
        score++; g = Math.min(1000, LV.g[L()] + score * 14); hud();
        foot = { x: c.x, y: c.y + 26, life: 0.35 };
      }
    });

    function drawShuttle(x, y, vx, vy) {
      const a = Math.atan2(vy, vx || 0.001) + Math.PI; // feathers trail behind motion
      const dir = (Math.abs(vy) < 40 && Math.abs(vx) < 40) ? -Math.PI / 2 : a;
      ctx.save(); ctx.translate(x, y); ctx.rotate(dir + Math.PI / 2);
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2.5;
      for (let i = -2; i <= 2; i++) { ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(i * 6, -26); ctx.stroke(); }
      ctx.strokeStyle = '#2f6db3'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-12, -24); ctx.lineTo(12, -24); ctx.stroke();
      ctx.fillStyle = '#a3271f'; ctx.beginPath(); ctx.arc(0, 2, 7, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }
    reset();

    api.loop(dt => {
      if (running) {
        windT -= dt; if (windT <= 0) { wind = (Math.random() * 2 - 1) * LV.wind[L()]; windT = 2 + Math.random() * 2; }
        c.vx += wind * dt; c.vy += g * dt; c.x += c.vx * dt; c.y += c.vy * dt;
        if (c.x < 14 || c.x > W - 14) { c.vx *= -0.8; c.x = Math.max(14, Math.min(W - 14, c.x)); }
        if (c.y < 14) { c.y = 14; c.vy = Math.abs(c.vy) * 0.3; }
        if (c.y >= groundY) {
          c.y = groundY; running = false; dead = true; root.querySelector('.start').hidden = false;
          api.over({ title: t('Cầu rơi rồi! 🪶', 'It hit the ground! 🪶'), text: t(`Bạn tâng được ${score} lần.`, `You kept it up for ${score} kicks.`), score, passed: score >= LV.goal[L()], restart: start });
        }
      }
      const sky = ctx.createLinearGradient(0, 0, 0, H); sky.addColorStop(0, '#9fd3f5'); sky.addColorStop(1, '#e4f4ff');
      ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#d8b26a'; ctx.fillRect(0, groundY + 8, W, H - groundY);
      ctx.fillStyle = 'rgba(0,0,0,.15)'; const sh = Math.max(4, 16 - (groundY - c.y) / 25);
      ctx.beginPath(); ctx.ellipse(c.x, groundY + 10, sh, 4, 0, 0, Math.PI * 2); ctx.fill();
      drawShuttle(c.x, c.y, c.vx, c.vy);
      if (foot && foot.life > 0) { foot.life -= dt; ctx.globalAlpha = Math.max(0, foot.life / 0.35); ctx.fillStyle = '#000'; ctx.font = '36px serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('🦶', foot.x, foot.y); ctx.globalAlpha = 1; }
      if (!running && !dead) { ctx.fillStyle = '#2a1d14'; ctx.font = '600 16px "Be Vietnam Pro", sans-serif'; ctx.textAlign = 'center'; ctx.fillText(t('Chạm vào quả cầu để đá', 'Tap the shuttlecock to kick'), W / 2, H * 0.55); }
    });
    hud();
  }
});
