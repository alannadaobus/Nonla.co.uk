// Bầu Cua Tôm Cá – Tết dice game (play money only)
Core.register({
  id: 'baucua', icon: '🦀',
  name: { vi: 'Bầu Cua Tôm Cá', en: 'Gourd Crab Shrimp Fish' },
  tag: { vi: 'Trò xúc xắc ngày Tết', en: 'The Tết New Year dice game' },
  rules: {
    vi: 'Chọn mức cược rồi chạm vào linh vật để đặt. Bấm <b>Lắc</b>: mỗi xúc xắc trùng linh vật bạn đặt thì thắng bằng số tiền cược. Chỉ để vui, không dùng tiền thật!',
    en: 'Choose a chip and tap animals to bet, then <b>Roll</b>. You win your bet for each die that matches. Just for fun — no real money!'
  },
  fmtBest: (v, t) => v + t(' xu', ' coins'),
  mount(root, api) {
    const t = api.t;
    const ANIMALS = [[t('Nai', 'Deer'), '🦌'], [t('Bầu', 'Gourd'), '🍐'], [t('Gà', 'Rooster'), '🐓'], [t('Cá', 'Fish'), '🐟'], [t('Cua', 'Crab'), '🦀'], [t('Tôm', 'Shrimp'), '🦐']];
    root.innerHTML = `
      <div class="bc-bar"><strong>💰 <span class="coins">100</span> ${t('xu', 'coins')}</strong>
        <div class="chips"><button class="active">1</button><button>5</button><button>10</button></div></div>
      <div class="bc-board"></div>
      <div class="dice"><div class="die">❔</div><div class="die">❔</div><div class="die">❔</div></div>
      <div class="status">${t('Đặt cược đi nào!', 'Place your bets!')}</div>
      <div class="oaq-controls">
        <button class="btn roll">🎲 ${t('Lắc', 'Roll')}</button>
        <button class="btn outline small clr">${t('Xoá cược', 'Clear bets')}</button>
      </div>`;
    const $ = s => root.querySelector(s);
    const boardEl = $('.bc-board'), statusEl = $('.status'), dice = root.querySelectorAll('.die');
    let coins = 100, chip = 1, bets = Array(6).fill(0), rolling = false, peak = 100;
    ANIMALS.forEach(([n, e], i) => {
      const tl = document.createElement('div'); tl.className = 'bc-tile';
      tl.innerHTML = `<span class="bet"></span><div class="em">${e}</div><div class="name">${n}</div>`;
      tl.onclick = () => { if (rolling) return; if (coins < chip) { statusEl.textContent = t('Không đủ xu!', 'Not enough coins!'); return; } coins -= chip; bets[i] += chip; update(); };
      boardEl.appendChild(tl);
    });
    root.querySelectorAll('.chips button').forEach(b => b.onclick = () => { root.querySelectorAll('.chips button').forEach(x => x.classList.remove('active')); b.classList.add('active'); chip = +b.textContent; });
    function update(winners = []) {
      $('.coins').textContent = coins;
      [...boardEl.children].forEach((tl, i) => { tl.classList.toggle('has-bet', bets[i] > 0); tl.querySelector('.bet').textContent = bets[i]; tl.classList.toggle('win', winners.includes(i)); });
    }
    function restart() { coins = 100; peak = 100; bets.fill(0); update(); statusEl.textContent = t('Đặt cược đi nào!', 'Place your bets!'); api.hideOver(); }
    $('.clr').onclick = () => { if (rolling) return; coins += bets.reduce((a, b) => a + b, 0); bets.fill(0); update(); };
    $('.roll').onclick = async () => {
      if (rolling) return;
      const total = bets.reduce((a, b) => a + b, 0);
      if (!total) { statusEl.textContent = t('Hãy đặt cược trước!', 'Place a bet first!'); return; }
      rolling = true; statusEl.textContent = t('Đang lắc…', 'Rolling…');
      dice.forEach(d => d.classList.add('rolling'));
      for (let k = 0; k < 12; k++) { dice.forEach(d => d.textContent = ANIMALS[Math.floor(Math.random() * 6)][1]); await api.sleep(80); if (!api.alive()) return; }
      const res = [0, 1, 2].map(() => Math.floor(Math.random() * 6));
      dice.forEach((d, k) => { d.classList.remove('rolling'); d.textContent = ANIMALS[res[k]][1]; });
      let won = 0;
      bets.forEach((b, i) => { if (!b) return; const hits = res.filter(r => r === i).length; if (hits) won += b + b * hits; });
      coins += won; const net = won - total;
      statusEl.textContent = (net > 0 ? t(`🎉 Thắng ${net} xu!`, `🎉 You won ${net} coins!`) : net === 0 ? t('Hoà vốn!', 'Broke even!') : t(`😅 Thua ${-net} xu.`, `😅 Lost ${-net} coins.`)) + ' — ' + res.map(r => ANIMALS[r][0]).join(', ');
      bets.fill(0); update([...new Set(res)]); rolling = false;
      if (coins > peak) { peak = coins; }
      if (coins === 0) api.over({ title: t('Hết xu rồi! 🪙', 'Out of coins! 🪙'), text: t(`Số xu cao nhất bạn đạt được: ${peak}`, `Your highest balance: ${peak} coins`), score: peak, restart });
      else if (coins >= 300 && peak === coins) api.over({ title: t('Đại gia! 🤑', 'High roller! 🤑'), text: t(`Bạn đã có ${coins} xu. Chơi tiếp hay thử trò khác?`, `You have ${coins} coins. Keep going or try another game?`), score: coins, restart });
    };
    update();
  }
});
