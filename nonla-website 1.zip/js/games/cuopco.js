// Cướp Cờ – Capture the Flag (reaction game)
Core.register({
  id: 'cuopco', icon: '🚩',
  name: { vi: 'Cướp Cờ', en: 'Capture the Flag' },
  tag: { vi: 'Phản xạ nhanh', en: 'Quick reflexes' },
  rules: {
    vi: 'Mỗi lượt bạn được một <b>số</b>. Trọng tài sẽ gọi số — khi gọi <b>đúng số của bạn</b>, bấm <b>CƯỚP!</b> thật nhanh trước máy. Bấm khi gọi số khác là <b>phạm quy</b>. Ai được 5 điểm trước thì thắng.',
    en: 'Each round you get a <b>number</b>. The referee calls out numbers — when <b>your number</b> is called, hit <b>GRAB!</b> before the computer does. Tapping on someone else’s number is a <b>foul</b>. First to 5 points wins.'
  },
  fmtBest: v => v + ' ms',
  mount(root, api) {
    const t = api.t;
    root.innerHTML = `
      <div class="cc-arena">
        <div class="cc-side"><div>${t('Bạn', 'You')}</div><span class="num me-num">?</span><div class="hud" style="justify-content:center;margin:6px 0 0">⭐ <span class="me-sc">0</span></div></div>
        <div class="cc-flag">🚩</div>
        <div class="cc-side cpu"><div>${t('Máy', 'CPU')}</div><span class="num">?</span><div class="hud" style="justify-content:center;margin:6px 0 0">⭐ <span class="cpu-sc">0</span></div></div>
      </div>
      <div class="cc-call"></div>
      <div class="status"></div>
      <div class="btn-line"><button class="tap-btn red grab">🚩 ${t('CƯỚP!', 'GRAB!')}</button></div>
      <div class="oaq-controls"><button class="btn start">▶ ${t('Bắt đầu', 'Start')}</button></div>`;
    const LV = { base: [680, 590, 510, 440, 380], min: [330, 300, 270, 240, 215] }, L = () => api.level() - 1;
    api.levelBar(root, 5, () => { running = false; if (cpuT) api.clear(cpuT); if (callT) api.clear(callT); root.querySelector('.start').hidden = false; api.hideOver(); });
    const $ = s => root.querySelector(s);
    const callEl = $('.cc-call'), statusEl = $('.status'), flag = $('.cc-flag');
    let me = 0, cpu = 0, myNum = 0, armed = false, decoy = false, callAt = 0, cpuT = null, callT = null, running = false, bestRx = null;
    const r5 = () => 1 + Math.floor(Math.random() * 5);

    function score() { $('.me-sc').textContent = me; $('.cpu-sc').textContent = cpu; }
    function newRound() {
      myNum = r5(); $('.me-num').textContent = myNum; armed = decoy = false;
      flag.style.transform = ''; callEl.textContent = t('Chuẩn bị...', 'Get ready...');
      callT = api.timeout(makeCall, 900 + Math.random() * 1400);
    }
    function makeCall() {
      const mine = Math.random() < 0.4;
      let n = myNum; if (!mine) { do { n = r5(); } while (n === myNum); }
      callEl.textContent = t(`Số ${n}!`, `Number ${n}!`);
      if (mine) {
        armed = true; callAt = performance.now();
        const delay = Math.max(LV.min[L()], LV.base[L()] - (me + cpu) * 15 + (Math.random() * 160 - 80));
        cpuT = api.timeout(() => point('cpu', t('Máy cướp được cờ! 🏃', 'The computer grabbed the flag! 🏃')), delay);
      } else {
        decoy = true;
        callT = api.timeout(() => { decoy = false; callEl.textContent = '...'; callT = api.timeout(makeCall, 500 + Math.random() * 1100); }, 900);
      }
    }
    function point(who, msg) {
      armed = decoy = false; if (who === 'me') me++; else cpu++;
      score(); statusEl.textContent = msg;
      flag.style.transform = who === 'me' ? 'translateX(-60px) rotate(-15deg)' : 'translateX(60px) rotate(15deg)';
      if (me >= 5 || cpu >= 5) {
        running = false; $('.start').hidden = false; callEl.textContent = me >= 5 ? '🏆' : '😅';
        api.over({
          title: me >= 5 ? t('Bạn thắng! 🎉', 'You win! 🎉') : t('Máy thắng rồi!', 'The computer wins!'),
          text: `${t('Tỉ số', 'Score')} ${me} – ${cpu}` + (bestRx ? ` · ${t('Phản xạ nhanh nhất', 'Fastest reaction')}: ${bestRx} ms` : ''),
          score: bestRx ?? undefined, lowerIsBetter: true, passed: me >= 5, restart: start
        });
      } else callT = api.timeout(newRound, 1500);
    }
    api.on($('.grab'), 'pointerdown', e => {
      e.preventDefault();
      if (!running) return;
      if (armed) {
        api.clear(cpuT);
        const ms = Math.round(performance.now() - callAt);
        if (bestRx === null || ms < bestRx) bestRx = ms;
        point('me', t(`Nhanh quá! ${ms} ms ⚡`, `Fast! ${ms} ms ⚡`));
      } else if (decoy) {
        api.clear(callT);
        point('cpu', t('Phạm quy! Không phải số của bạn. ❌', 'Foul! That wasn’t your number. ❌'));
      }
    });
    function start() {
      api.hideOver(); if (cpuT) api.clear(cpuT); if (callT) api.clear(callT);
      me = cpu = 0; bestRx = null; score(); statusEl.textContent = ''; running = true; $('.start').hidden = true; newRound();
    }
    $('.start').onclick = start;
    callEl.textContent = t('Sẵn sàng?', 'Ready?');
  }
});
