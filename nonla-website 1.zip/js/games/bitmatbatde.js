// Bịt Mắt Bắt Dê – Blindfolded Goat Catching
Core.register({
  id: 'bitmat', icon: '🐐',
  name: { vi: 'Bịt Mắt Bắt Dê', en: 'Blindfold Goat Catch' },
  tag: { vi: 'Nghe tiếng "be be" mà bắt', en: 'Follow the bleats' },
  rules: {
    vi: 'Bạn đang bị bịt mắt! Chạm vào màn hình tối để chụp con dê 🐐. Nghe tiếng <b>"Be be!"</b> và gợi ý <b>Nóng / Ấm / Lạnh</b> để đoán vị trí. Bắt càng nhiều càng tốt trong 40 giây.',
    en: 'You are blindfolded! Tap the dark field to grab the goat 🐐. Use its <b>"Baa!"</b> bleats and the <b>Hot / Warm / Cold</b> hints to find it. Catch as many as you can in 40 seconds.'
  },
  fmtBest: (v, t) => v + t(' con', ' goats'),
  mount(root, api) {
    const t = api.t;
    root.innerHTML = `<div class="goal"></div><div class="hud"><span class="sc"></span><span class="tm"></span></div><div class="cvw"></div>
      <div class="oaq-controls"><button class="btn start">▶ ${t('Bắt đầu', 'Start')}</button></div>`;
    const LV = { sp: [40, 55, 70, 85, 100], r: [48, 44, 40, 36, 32], goal: [4, 5, 6, 7, 8] }, L = () => api.level() - 1;
    api.levelBar(root, 5, () => { running = false; reset(); hud(); root.querySelector('.start').hidden = false; api.hideOver(); });
    const { cv, ctx, W, H, pos } = api.canvas(root.querySelector('.cvw'), 0.75);
    let goat, score = 0, timeLeft = 40, running = false, reveals = [], bleats = [], hints = [], bleatT = 0, flash = 0;
    let R = 46;

    function pickDir() { const a = Math.random() * Math.PI * 2; goat.vx = Math.cos(a) * goat.speed; goat.vy = Math.sin(a) * goat.speed; goat.turn = 0.8 + Math.random() * 1.5; }
    function respawn(awayX, awayY) {
      do { goat.x = 30 + Math.random() * (W - 60); goat.y = 30 + Math.random() * (H - 60); } while (Math.hypot(goat.x - awayX, goat.y - awayY) < 150);
      pickDir();
    }
    function reset() {
      R = LV.r[L()]; goat = { x: W / 2, y: H / 2, speed: LV.sp[L()] }; respawn(W / 2, H / 2);
      score = 0; timeLeft = 40; reveals = []; bleats = []; hints = []; bleatT = 0.8; flash = 0;
    }
    function hud() {
      root.querySelector('.sc').textContent = `🐐 ${score}`;
      root.querySelector('.goal').innerHTML = `🎯 ${t('Mục tiêu', 'Goal')}: ${LV.goal[L()]} ${t('con dê', 'goats')}${score >= LV.goal[L()] ? ' ✅' : ''}`;
      root.querySelector('.tm').textContent = `⏱ ${Math.ceil(timeLeft)}s`;
    }

    api.on(cv, 'pointerdown', e => {
      if (!running) return;
      const p = pos(e), d = Math.hypot(p.x - goat.x, p.y - goat.y);
      reveals.push({ x: p.x, y: p.y, life: 0.7 });
      if (d < R) {
        score++; flash = 0.7; goat.speed += 10;
        hints.push({ txt: t('Bắt được! 🎉', 'Caught! 🎉'), x: p.x, y: p.y - 34, life: 1, c: '#ffd36b' });
        flash = { x: goat.x, y: goat.y, life: 0.7 };
        respawn(p.x, p.y);
      } else {
        const txt = d < 110 ? t('Nóng! 🔥', 'Hot! 🔥') : d < 200 ? t('Ấm 🙂', 'Warm 🙂') : t('Lạnh ❄️', 'Cold ❄️');
        hints.push({ txt, x: p.x, y: p.y - 34, life: 0.9, c: d < 110 ? '#ff8a5c' : d < 200 ? '#ffd36b' : '#9ad0ff' });
      }
      hud();
    });

    function start() {
      api.hideOver(); reset(); running = true; hud();
      root.querySelector('.start').hidden = true;
    }
    root.querySelector('.start').onclick = start;

    function emoji(ch, x, y, size) { ctx.fillStyle = '#000'; ctx.font = `${size}px serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(ch, x, y); }

    api.loop(dt => {
      if (running) {
        goat.x += goat.vx * dt; goat.y += goat.vy * dt;
        if (goat.x < 20 || goat.x > W - 20) { goat.vx *= -1; goat.x = Math.max(20, Math.min(W - 20, goat.x)); }
        if (goat.y < 20 || goat.y > H - 20) { goat.vy *= -1; goat.y = Math.max(20, Math.min(H - 20, goat.y)); }
        goat.turn -= dt; if (goat.turn <= 0) pickDir();
        bleatT -= dt; if (bleatT <= 0) { bleats.push({ x: goat.x, y: goat.y, life: 1 }); bleatT = 1.4 + Math.random() * 1.2; }
        timeLeft -= dt; hud();
        if (timeLeft <= 0) {
          running = false; timeLeft = 0; hud(); root.querySelector('.start').hidden = false;
          api.over({ title: t(`Bạn bắt được ${score} con dê!`, `You caught ${score} goat${score === 1 ? '' : 's'}!`), text: score >= 6 ? t('Tai thính quá! 👂', 'Great ears! 👂') : t('Thử lại để phá kỷ lục nhé!', 'Try again to beat your best!'), score, passed: score >= LV.goal[L()], restart: start });
        }
      }
      // draw
      ctx.fillStyle = '#17110c'; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = 'rgba(255,255,255,.03)';
      for (let i = 0; i < 40; i++) ctx.fillRect((i * 97) % W, (i * 53) % H, 2, 2);
      reveals.forEach(r => {
        r.life -= dt;
        ctx.save(); ctx.globalAlpha = Math.max(0, r.life / 0.7);
        ctx.beginPath(); ctx.arc(r.x, r.y, R, 0, Math.PI * 2); ctx.fillStyle = '#5e7d3a'; ctx.fill(); ctx.clip();
        if (goat) emoji('🐐', goat.x, goat.y, 34);
        ctx.restore();
      });
      reveals = reveals.filter(r => r.life > 0);
      if (flash && flash.life > 0) { flash.life -= dt; ctx.globalAlpha = Math.max(0, flash.life / 0.7); emoji('🐐', flash.x, flash.y, 44); ctx.globalAlpha = 1; }
      bleats.forEach(b => { b.life -= dt * 0.8; ctx.globalAlpha = Math.max(0, b.life) * 0.55; ctx.fillStyle = '#f3e6c8'; ctx.font = '600 15px "Be Vietnam Pro", sans-serif'; ctx.textAlign = 'center'; ctx.fillText(t('Be be!', 'Baa!'), b.x, b.y); });
      bleats = bleats.filter(b => b.life > 0);
      hints.forEach(h => { h.life -= dt; h.y -= 20 * dt; ctx.globalAlpha = Math.max(0, h.life); ctx.fillStyle = h.c; ctx.font = '700 18px "Be Vietnam Pro", sans-serif'; ctx.textAlign = 'center'; ctx.fillText(h.txt, h.x, h.y); });
      hints = hints.filter(h => h.life > 0);
      ctx.globalAlpha = 1;
      if (!running && (!goat || timeLeft === 40)) {
        emoji('🙈', W / 2, H / 2 - 20, 56);
        ctx.fillStyle = '#f3e6c8'; ctx.font = '600 16px "Be Vietnam Pro", sans-serif'; ctx.textAlign = 'center';
        ctx.fillText(t('Bấm Bắt đầu rồi chạm để bắt dê', 'Press Start, then tap to catch'), W / 2, H / 2 + 30);
      }
    });
    hud();
  }
});
