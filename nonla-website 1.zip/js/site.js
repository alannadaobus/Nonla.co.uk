// =====================================================================
// Nón Lá – shared site script (homepage + blog): language, menu, shop, art.
// ✏️ EDIT MENU / PRODUCTS BELOW. Every text has a Vietnamese (vi) and English (en) version.
// =====================================================================

// ---------- Language (shared with the games page) ----------
const Site = (() => {
  let lang;
  try { lang = JSON.parse(localStorage.getItem('nonla_lang')); } catch (e) { }
  if (lang !== 'vi' && lang !== 'en') lang = (navigator.language || 'en').toLowerCase().startsWith('vi') ? 'vi' : 'en';
  const listeners = [];
  return {
    get lang() { return lang; },
    t: (vi, en) => (lang === 'vi' ? vi : en),
    pick: o => (o && typeof o === 'object' ? (o[lang] ?? o.en ?? o.vi) : o),
    toggle() { lang = lang === 'vi' ? 'en' : 'vi'; try { localStorage.setItem('nonla_lang', JSON.stringify(lang)); } catch (e) { } this.apply(); },
    onChange(fn) { listeners.push(fn); },
    apply() {
      document.documentElement.lang = lang;
      document.querySelectorAll('[data-vi]').forEach(el => { el.innerHTML = el.dataset[lang]; });
      document.querySelectorAll('[data-lang]').forEach(el => { el.hidden = el.dataset.lang !== lang; });
      document.querySelectorAll('[data-ph-vi]').forEach(el => { el.placeholder = el.dataset['ph' + (lang === 'vi' ? 'Vi' : 'En')]; });
      const b = document.getElementById('langBtn'); if (b) b.textContent = lang === 'vi' ? '🇬🇧 EN' : '🇻🇳 VI';
      listeners.forEach(fn => fn(lang));
    }
  };
})();

// ---------- ✏️ MENU – fast Vietnamese street food (no noodle soups) ----------
const MENU = [
  { cat: { vi: 'Bánh mì', en: 'Bánh mì' }, items: [
    { name: 'Bánh mì thịt nướng', desc: { vi: 'Thịt heo nướng sả, đồ chua, rau mùi, ớt', en: 'Lemongrass grilled pork, pickles, coriander, chilli' }, price: '£7.50' },
    { name: 'Bánh mì gà sả', desc: { vi: 'Gà nướng sả ớt, sốt bơ trứng', en: 'Lemongrass chilli chicken, house mayo' }, price: '£7.50' },
    { name: 'Bánh mì chả lụa pa-tê', desc: { vi: 'Chả lụa, pa-tê gan, dưa leo — kiểu Sài Gòn', en: 'Pork roll, liver pâté, cucumber — Saigon style' }, price: '£7.90' },
    { name: 'Bánh mì trứng', desc: { vi: 'Trứng ốp la, xì dầu, hành phi', en: 'Fried eggs, soy, crispy shallots' }, price: '£6.50' },
    { name: 'Bánh mì đậu hũ (V)', desc: { vi: 'Đậu hũ sả ớt, nấm, đồ chua', en: 'Lemongrass tofu, mushrooms, pickles' }, price: '£6.90' },
  ]},
  { cat: { vi: 'Cuốn & Chiên', en: 'Rolls & Crispy' }, items: [
    { name: 'Gỏi cuốn tôm thịt', desc: { vi: 'Cuốn tươi tôm, thịt, rau thơm, chấm tương đậu phộng', en: 'Fresh rolls, prawn & pork, herbs, peanut dip' }, price: '£6.50' },
    { name: 'Gỏi cuốn chay (V)', desc: { vi: 'Đậu hũ, xoài, rau thơm', en: 'Tofu, mango, fresh herbs' }, price: '£5.90' },
    { name: 'Chả giò', desc: { vi: 'Nem rán giòn, nước chấm', en: 'Crispy spring rolls, nước chấm dip' }, price: '£6.90' },
    { name: 'Bánh xèo', desc: { vi: 'Bánh xèo nghệ giòn, tôm thịt, rau sống', en: 'Crispy turmeric pancake, prawn & pork, lettuce wraps' }, price: '£8.50' },
    { name: 'Bánh bao xá xíu', desc: { vi: 'Bánh bao nhân thịt xá xíu, trứng cút', en: 'Steamed bun with char siu pork & quail egg' }, price: '£4.50' },
  ]},
  { cat: { vi: 'Cơm & Bún trộn', en: 'Quick Rice & Noodle Bowls' }, items: [
    { name: 'Cơm tấm sườn', desc: { vi: 'Cơm tấm, sườn nướng, mỡ hành, nước mắm', en: 'Broken rice, grilled pork chop, spring onion oil' }, price: '£11.90' },
    { name: 'Bún thịt nướng', desc: { vi: 'Bún trộn khô, thịt nướng, chả giò, rau, đậu phộng', en: 'Dry vermicelli bowl, grilled pork, spring roll, herbs, peanuts' }, price: '£11.50' },
    { name: 'Xôi gà', desc: { vi: 'Xôi nếp, gà xé, hành phi', en: 'Sticky rice, shredded chicken, crispy shallots' }, price: '£8.90' },
  ]},
  { cat: { vi: 'Đồ uống', en: 'Drinks' }, items: [
    { name: 'Cà phê sữa đá', desc: { vi: 'Cà phê phin, sữa đặc, đá', en: 'Phin-dripped coffee, condensed milk, ice' }, price: '£3.90' },
    { name: 'Cà phê trứng', desc: { vi: 'Kem trứng đánh bông kiểu Hà Nội', en: 'Hanoi-style whipped egg coffee' }, price: '£4.50' },
    { name: 'Trà chanh', desc: { vi: 'Trà xanh, chanh tươi', en: 'Iced green tea with fresh lime' }, price: '£3.50' },
    { name: 'Sinh tố bơ', desc: { vi: 'Bơ xay, sữa đặc', en: 'Avocado smoothie with condensed milk' }, price: '£4.90' },
  ]},
];

// ---------- ✏️ PRODUCTS – nón lá (all ≤ £29.90) ----------
// To use a real photo: upload it to /images/ and set img: 'images/your-photo.jpg'.
// Leave img empty to show the painted illustration.
const PRODUCTS = [
  { name: { vi: 'Nón Lá Truyền Thống', en: 'Classic Nón Lá' }, desc: { vi: 'Lá nón tự nhiên, 16 vành tre, quai lụa.', en: 'Natural palm leaf, 16 bamboo rings, silk chin strap.' }, price: '£14.90', art: 'plain', img: '' },
  { name: { vi: 'Nón Bài Thơ Huế', en: 'Huế Poem Hat' }, desc: { vi: 'Soi lên ánh sáng sẽ thấy thơ và cảnh Huế giữa hai lớp lá.', en: 'Hold it to the light to see poems and Huế scenes between the leaves.' }, price: '£19.90', art: 'poem', img: '' },
  { name: { vi: 'Nón Sen Hồng Vẽ Tay', en: 'Hand-painted Pink Lotus' }, desc: { vi: 'Sen hồng vẽ tay trên nền lá tự nhiên.', en: 'Pink lotus hand-painted on natural leaf.' }, price: '£24.90', art: 'pinkLotus', img: '' },
  { name: { vi: 'Nón Sen Trắng Lá Biếc', en: 'White Lotus on Green' }, desc: { vi: 'Sen trắng trên nền xanh lá sen — món quà sang trọng.', en: 'White lotus on lotus-leaf green — an elegant gift.' }, price: '£26.90', art: 'whiteLotus', img: '' },
  { name: { vi: 'Nón Màu Nghệ Thuật', en: 'Colour Art Hat' }, desc: { vi: 'Nền xanh đậm, sen vàng vẽ tay, treo tường rất đẹp.', en: 'Deep navy with a hand-painted golden lotus — lovely on a wall.' }, price: '£29.90', art: 'navyLotus', img: '' },
  { name: { vi: 'Bộ Nón Mini (3 chiếc)', en: 'Mini Hat Set (3)' }, desc: { vi: 'Nón nhỏ trang trí, quà lưu niệm, cho bé.', en: 'Small decorative hats — souvenirs, parties, kids.' }, price: '£12.90', art: 'mini', img: '' },
];

// ---------- Painted-hat illustrations (SVG, no photos needed) ----------
function lotusSVG(cx, cy, s, petal, centre) {
  let g = '';
  [-50, -25, 0, 25, 50].forEach((a, i) => {
    const h = (i === 2 ? 26 : 21) * s;
    g += `<ellipse cx="${cx}" cy="${cy - h / 2}" rx="${6.5 * s}" ry="${h / 2}" fill="${petal}" stroke="rgba(150,40,80,.35)" stroke-width="${0.8 * s}" transform="rotate(${a} ${cx} ${cy})"/>`;
  });
  return g + `<ellipse cx="${cx}" cy="${cy - 2 * s}" rx="${6 * s}" ry="${3 * s}" fill="${centre}"/>`;
}
function leafSVG(cx, cy, s, col) {
  return `<ellipse cx="${cx}" cy="${cy}" rx="${22 * s}" ry="${8 * s}" fill="${col}"/><path d="M${cx - 20 * s} ${cy} L${cx + 20 * s} ${cy}" stroke="rgba(0,0,0,.2)" stroke-width="${s}"/>`;
}
function hatSVG(art) {
  const base = { plain: '#e6cf99', poem: '#efe3c3', pinkLotus: '#e3c78e', whiteLotus: '#5f9a55', navyLotus: '#26326b', mini: '#e6cf99' }[art] || '#e6cf99';
  let motif = '';
  if (art === 'pinkLotus') motif = leafSVG(70, 74, 1, '#4d8c3f') + leafSVG(128, 80, 0.8, '#3f7a35') + lotusSVG(95, 72, 1.1, '#ef7fae', '#f5d36b') + lotusSVG(132, 70, 0.6, '#f49bc0', '#f5d36b');
  if (art === 'whiteLotus') motif = leafSVG(120, 78, 1, '#3d7a3a') + lotusSVG(90, 74, 1.2, '#fbf8ef', '#f2cf55') + lotusSVG(128, 66, 0.55, '#fbf8ef', '#f2cf55');
  if (art === 'navyLotus') motif = leafSVG(72, 78, 0.9, '#3a7f8c') + lotusSVG(100, 74, 1.15, '#f6cd4c', '#e98b2a');
  if (art === 'poem') motif = `<g fill="none" stroke="#b9a173" stroke-width="1.2" opacity=".8"><path d="M70 74 q8 -8 16 0 t16 0"/><path d="M104 66 q6 -6 12 0 t12 0"/><path d="M84 52 l4 -10 l4 10"/></g>`;
  const rings = Array.from({ length: 7 }, (_, i) => { const y = 24 + i * 9.5, hw = (y - 10) * 1.0; return `<path d="M${100 - hw} ${y} Q100 ${y + 3} ${100 + hw} ${y}" stroke="rgba(110,80,30,.22)" stroke-width="1" fill="none"/>`; }).join('');
  const one = (dx, dy, k) => `<g transform="translate(${dx} ${dy}) scale(${k})">
    <defs><clipPath id="hc-${art}-${dx}"><path d="M100 10 L176 86 Q100 104 24 86 Z"/></clipPath></defs>
    <path d="M100 10 L176 86 Q100 104 24 86 Z" fill="${base}" stroke="#7d5a2a" stroke-width="2.5" stroke-linejoin="round"/>
    <g clip-path="url(#hc-${art}-${dx})">${rings}${motif}
      <path d="M100 10 L176 86 Q100 104 24 86 Z" fill="url(#shade)"/></g>
    <path d="M24 86 Q100 104 176 86" stroke="#7d5a2a" stroke-width="3" fill="none"/></g>`;
  const body = art === 'mini' ? one(-28, 18, 0.62) + one(62, 18, 0.62) + one(17, -4, 0.7) : one(0, 0, 1);
  return `<svg viewBox="0 0 200 110" role="img" aria-label="nón lá"><defs><linearGradient id="shade" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity=".18"/><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".22"/></linearGradient></defs>${body}</svg>`;
}
