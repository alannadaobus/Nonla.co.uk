# Hướng dẫn – nonla.co.uk

## 1. Cập nhật web (khi có file zip mới)
Cloudflare → **Workers & Pages** → project của web → **Create deployment / Upload** → chọn file zip.

## 2. Cài máy chủ thành viên + bài viết (làm MỘT LẦN, khoảng 15 phút)
Tất cả nằm trong một Worker tên `nonla-api` tại địa chỉ `https://api.nonla.co.uk`.

**Bước A – Tạo cơ sở dữ liệu D1 (miễn phí)**
1. Cloudflare → **Storage & Databases → D1 SQL Database → Create** → đặt tên `nonla-db` → **Create**.
2. Mở `nonla-db` → tab **Console** → dán toàn bộ nội dung file `worker/schema.sql` → **Execute**.

**Bước B – Tạo Worker**
1. **Workers & Pages → Create → Worker → Start with "Hello World"** → tên `nonla-api` → **Deploy**.
2. **Edit code** → xoá code mẫu → dán toàn bộ file `worker/nonla-api.js` → **Deploy**.

**Bước C – Kết nối cơ sở dữ liệu và mã nhân viên**
1. Worker `nonla-api` → **Settings → Bindings → Add → D1 database** → Variable name: `DB` → chọn `nonla-db` → **Save/Deploy**.
2. **Settings → Variables and Secrets → Add** → Type: **Secret** → Name: `ADMIN_KEY` → Value: một mật mã dài ít nhất 12 ký tự (chỉ đưa cho nhân viên) → **Deploy**.

**Bước D – Gắn tên miền**
Worker `nonla-api` → **Settings → Domains & Routes → Add → Custom domain** → `api.nonla.co.uk`.

**Kiểm tra:** mở `https://api.nonla.co.uk/posts` thấy chữ `[{"id":...` là xong. Vào `nonla.co.uk/account.html` thử đăng ký.

## 3. Thêm bài viết mà KHÔNG cần tải lại web
Worker `nonla-api` → **Edit code** → phần `✏️ 1) BLOG POSTS` ở đầu file → thêm một khối `{ ... }` → **Deploy**.
Bài có `date` trong tương lai sẽ tự đăng đúng ngày.

| Ngày | Bài viết | Nơi lưu |
|---|---|---|
| 21/11/2026 | Văn hóa Việt, tâm hồn Việt: Hương phở sớm mai và vành nón quê nhà | js/posts.js |
| 28/11/2026 | Thổ cẩm – Những sợi chỉ kể chuyện núi rừng Tây Bắc | js/posts.js |
| 05/12/2026 | Áo dài – Dáng Việt thướt tha qua mọi thời đại | js/posts.js |
| 12/12/2026 | Nón lá – Món quà mang cả quê hương *(bài mẫu, cần viết)* | Worker |

## 4. Xu & voucher
- Sửa luật ở phần `✏️ 2) REWARD RULES` trong Worker: 500 xu = giảm 10%, 1000 xu = giảm 20%, tối đa 60 xu/ngày, voucher hạn 30 ngày.
- Bầu Cua không tích xu (trò may rủi).
- **Nhân viên kiểm voucher:** mở `nonla.co.uk/staff.html` → nhập ADMIN_KEY → nhập mã khách đưa → bấm "Dùng tại quán" hoặc "Dùng cho đơn online".

## 5. Trước khi chạy chính thức
- Điền **[tên pháp lý doanh nghiệp, địa chỉ]** trong `privacy.html` và `terms.html`, kiểm tra danh sách chất gây dị ứng.
- Nên nhờ người có chuyên môn pháp lý xem lại Chính sách bảo mật và Điều khoản.
- Cân nhắc đăng ký với ICO (phí bảo vệ dữ liệu): ico.org.uk.

## 6. Sửa thực đơn và giá nón
File `js/site.js` → `MENU` và `PRODUCTS`. Ảnh nón thật: đặt vào `images/` rồi ghi `img: 'images/ten-anh.jpg'`.
