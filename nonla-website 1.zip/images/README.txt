Đặt ảnh nón lá của bạn vào thư mục này (vd: non-sen-hong.jpg) rồi khai báo trong js/site.js
