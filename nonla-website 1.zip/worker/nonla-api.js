// =====================================================================
// NÓN LÁ API – one Cloudflare Worker at https://api.nonla.co.uk
//   • /posts            – extra blog posts you can edit right here in the dashboard
//   • /auth/*, /me/*    – member accounts (email + password)
//   • /coins/earn       – coins from folk games (limited per day, checked on the server)
//   • /vouchers/*       – swap coins for % discount vouchers
//   • /admin/*          – staff check/mark vouchers (needs the ADMIN_KEY secret)
// Needs: D1 database bound as `DB` (run worker/schema.sql once) and a secret `ADMIN_KEY`.
// =====================================================================

// ---------------------------------------------------------------------
// ✏️ 1) BLOG POSTS – add a { ... } block, then press Deploy. (date in the future = scheduled)
// ---------------------------------------------------------------------
const POSTS = [
  {
    id: 'non-la-qua-tang',
    date: '2026-12-12',
    author: 'Alanna Dao',
    cover: 'pho', // 'pho' | 'thocam' | 'aodai'  — or use coverImg: 'https://nonla.co.uk/images/photo.jpg'
    title: { vi: 'Nón lá – Món quà mang cả quê hương', en: 'The Conical Hat: A Gift That Carries a Homeland' },
    excerpt: { vi: 'Gợi ý chọn nón lá làm quà Giáng sinh và Tết.', en: 'How to choose a nón lá as a Christmas or Lunar New Year gift.' },
    body: {
      vi: `<p>(Bài mẫu – hãy thay nội dung.) Nón lá là món quà nhẹ, đẹp và đậm chất Việt…</p>`,
      en: `<p>(Sample post – replace this text.) A conical hat is a light, beautiful gift full of Vietnamese character…</p>`
    }
  },
];

// ---------------------------------------------------------------------
// ✏️ 2) REWARD RULES
// ---------------------------------------------------------------------
const TIERS = {                       // coins → % off one order (in store or online hat order)
  p10: { coins: 500, percent: 10 },
  p20: { coins: 1000, percent: 20 },
};
const VOUCHER_DAYS = 30;              // voucher validity
const DAILY_CAP = 60;                 // max coins a member can earn per day (UTC)
const COOLDOWN_SEC = 20;              // min seconds between two coin awards
const GAMES = ['oaq', 'keoco', 'bitmat', 'nhaysap', 'nhayday', 'rongran', 'cuopco', 'dacau', 'danhchuyen', 'danhcu', 'rps'];
// Bầu Cua ('baucua') is a game of chance → deliberately NOT in this list (no coins).
const ALLOWED_ORIGINS = ['https://nonla.co.uk', 'https://www.nonla.co.uk'];
const SESSION_DAYS = 30;

// =====================================================================
// Below: engine. You normally don't need to change anything here.
// =====================================================================
const enc = new TextEncoder();
const b64e = u8 => btoa(String.fromCharCode(...u8)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const b64d = s => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)), c => c.charCodeAt(0));
const hex = buf => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
const sha256 = async s => hex(await crypto.subtle.digest('SHA-256', enc.encode(s)));
function safeEqual(a, b) { if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }

async function hashPassword(pw, saltB64) {
  const salt = saltB64 ? b64d(saltB64) : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 100000 }, key, 256);
  return { hash: b64e(new Uint8Array(bits)), salt: b64e(salt) };
}
function voucherCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', r = crypto.getRandomValues(new Uint8Array(8));
  const s = [...r].map(x => A[x % A.length]).join('');
  return `NL-${s.slice(0, 4)}-${s.slice(4)}`;
}
const now = () => Date.now();
const dayStart = () => { const d = new Date(); d.setUTCHours(0, 0, 0, 0); return d.getTime(); };

class HttpError extends Error { constructor(status, code) { super(code); this.status = status; this.code = code; } }

function corsHeaders(req, allowCreds = true) {
  const o = req.headers.get('Origin');
  const h = { 'Vary': 'Origin' };
  if (o && (ALLOWED_ORIGINS.includes(o) || (globalThis.__DEV_ORIGIN && o === globalThis.__DEV_ORIGIN))) {
    h['Access-Control-Allow-Origin'] = o;
    if (allowCreds) h['Access-Control-Allow-Credentials'] = 'true';
    h['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS';
    h['Access-Control-Allow-Headers'] = 'content-type, x-admin-key';
  }
  return h;
}
function json(req, data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', ...corsHeaders(req), ...extra } });
}
async function body(req) {
  const len = +req.headers.get('content-length') || 0;
  if (len > 20000) throw new HttpError(413, 'too_large');
  try { const j = await req.json(); return j && typeof j === 'object' ? j : {}; } catch (e) { throw new HttpError(400, 'bad_json'); }
}
function cookie(req, name) { const m = (req.headers.get('Cookie') || '').match(new RegExp('(?:^|; )' + name + '=([^;]+)')); return m ? m[1] : null; }
const sessionCookie = (token, maxAge) => `nl_session=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}`;

async function currentUser(req, env) {
  const tok = cookie(req, 'nl_session'); if (!tok) return null;
  const s = await env.DB.prepare('SELECT user_id, expires_at FROM sessions WHERE token_hash = ?').bind(await sha256(tok)).first();
  if (!s || s.expires_at < now()) return null;
  return env.DB.prepare('SELECT id, email, name, phone, marketing, coins, created_at FROM users WHERE id = ?').bind(s.user_id).first();
}
async function requireUser(req, env) { const u = await currentUser(req, env); if (!u) throw new HttpError(401, 'not_signed_in'); return u; }
async function newSession(env, userId) {
  const token = b64e(crypto.getRandomValues(new Uint8Array(32)));
  await env.DB.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)').bind(await sha256(token), userId, now() + SESSION_DAYS * 864e5).run();
  return token;
}
function requireAdmin(req, env) {
  if (!env.ADMIN_KEY || env.ADMIN_KEY.length < 12) throw new HttpError(503, 'admin_not_configured');
  if (!safeEqual(req.headers.get('x-admin-key') || '', env.ADMIN_KEY)) throw new HttpError(403, 'forbidden');
}
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,24}$/;
const clean = (s, max) => String(s ?? '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, max);

async function meData(env, u) {
  const vouchers = (await env.DB.prepare('SELECT code, percent, status, created_at, expires_at, used_at FROM vouchers WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').bind(u.id).all()).results;
  const history = (await env.DB.prepare('SELECT amount, reason, game, created_at FROM coin_ledger WHERE user_id = ? ORDER BY id DESC LIMIT 20').bind(u.id).all()).results;
  const today = await env.DB.prepare("SELECT COALESCE(SUM(amount),0) AS s FROM coin_ledger WHERE user_id = ? AND reason = 'game' AND created_at >= ?").bind(u.id, dayStart()).first();
  vouchers.forEach(v => { if (v.status === 'active' && v.expires_at < now()) v.status = 'expired'; });
  return { user: { email: u.email, name: u.name, phone: u.phone || '', marketing: !!u.marketing, coins: u.coins, created_at: u.created_at }, vouchers, history, tiers: TIERS, dailyCap: DAILY_CAP, earnedToday: today.s };
}

async function route(req, env) {
  const url = new URL(req.url), p = url.pathname.replace(/\/+$/, '') || '/', m = req.method;
  if (m === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders(req) });
  if (p === '/posts' && m === 'GET') return new Response(JSON.stringify(POSTS), { headers: { 'content-type': 'application/json; charset=utf-8', 'access-control-allow-origin': '*', 'cache-control': 'public, max-age=60' } });
  if (!env.DB) throw new HttpError(503, 'db_not_configured');

  // CSRF protection: state-changing requests must come from our own website
  if (m === 'POST') {
    const o = req.headers.get('Origin');
    if (!o || !(ALLOWED_ORIGINS.includes(o) || (globalThis.__DEV_ORIGIN && o === globalThis.__DEV_ORIGIN))) throw new HttpError(403, 'bad_origin');
  }

  // ---------- Accounts ----------
  if (p === '/auth/register' && m === 'POST') {
    const b = await body(req);
    const email = clean(b.email, 254).toLowerCase(), name = clean(b.name, 60), pw = String(b.password || '');
    if (!EMAIL_RE.test(email)) throw new HttpError(400, 'bad_email');
    if (!name) throw new HttpError(400, 'bad_name');
    if (pw.length < 8 || pw.length > 128) throw new HttpError(400, 'weak_password');
    if (b.consent !== true) throw new HttpError(400, 'consent_required');
    if (await env.DB.prepare('SELECT 1 FROM users WHERE email = ?').bind(email).first()) throw new HttpError(409, 'email_taken');
    const { hash, salt } = await hashPassword(pw);
    const r = await env.DB.prepare('INSERT INTO users (email, name, pw_hash, pw_salt, marketing, coins, created_at, terms_at) VALUES (?, ?, ?, ?, ?, 0, ?, ?)')
      .bind(email, name, hash, salt, b.marketing === true ? 1 : 0, now(), now()).run();
    const token = await newSession(env, r.meta.last_row_id);
    return json(req, { ok: true }, 200, { 'Set-Cookie': sessionCookie(token, SESSION_DAYS * 86400) });
  }
  if (p === '/auth/login' && m === 'POST') {
    const b = await body(req);
    const email = clean(b.email, 254).toLowerCase(), pw = String(b.password || '').slice(0, 128);
    const ip = req.headers.get('CF-Connecting-IP') || 'local';
    const since = now() - 15 * 60e3;
    const fails = await env.DB.prepare('SELECT COALESCE(SUM(key = ?),0) AS e, COALESCE(SUM(key = ?),0) AS i FROM login_attempts WHERE key IN (?, ?) AND at > ?').bind('e:' + email, 'i:' + ip, 'e:' + email, 'i:' + ip, since).first();
    if (fails.e >= 8 || fails.i >= 30) throw new HttpError(429, 'too_many_attempts'); // 8 tries per account, 30 per IP, per 15 min
    const u = await env.DB.prepare('SELECT id, pw_hash, pw_salt FROM users WHERE email = ?').bind(email).first();
    const check = await hashPassword(pw, u ? u.pw_salt : 'AAAAAAAAAAAAAAAAAAAAAA'); // same work even if the email is unknown
    if (!u || !safeEqual(check.hash, u.pw_hash)) {
      await env.DB.batch([
        env.DB.prepare('INSERT INTO login_attempts (key, at) VALUES (?, ?)').bind('e:' + email, now()),
        env.DB.prepare('INSERT INTO login_attempts (key, at) VALUES (?, ?)').bind('i:' + ip, now()),
        env.DB.prepare('DELETE FROM login_attempts WHERE at < ?').bind(now() - 864e5),
      ]);
      throw new HttpError(401, 'wrong_login');
    }
    await env.DB.batch([
      env.DB.prepare('DELETE FROM login_attempts WHERE key = ?').bind('e:' + email),
      env.DB.prepare('DELETE FROM sessions WHERE expires_at < ?').bind(now()),
    ]);
    const token = await newSession(env, u.id);
    return json(req, { ok: true }, 200, { 'Set-Cookie': sessionCookie(token, SESSION_DAYS * 86400) });
  }
  if (p === '/auth/logout' && m === 'POST') {
    const tok = cookie(req, 'nl_session');
    if (tok) await env.DB.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(await sha256(tok)).run();
    return json(req, { ok: true }, 200, { 'Set-Cookie': sessionCookie('', 0) });
  }
  if (p === '/me' && m === 'GET') { const u = await requireUser(req, env); return json(req, await meData(env, u)); }
  if (p === '/me/update' && m === 'POST') {
    const u = await requireUser(req, env), b = await body(req);
    const name = clean(b.name, 60) || u.name, phone = clean(b.phone, 30).replace(/[^\d+ ()-]/g, '');
    await env.DB.prepare('UPDATE users SET name = ?, phone = ?, marketing = ? WHERE id = ?').bind(name, phone, b.marketing === true ? 1 : 0, u.id).run();
    return json(req, { ok: true });
  }
  if (p === '/me/password' && m === 'POST') {
    const u = await requireUser(req, env), b = await body(req);
    const row = await env.DB.prepare('SELECT pw_hash, pw_salt FROM users WHERE id = ?').bind(u.id).first();
    if (!safeEqual((await hashPassword(String(b.current || '').slice(0, 128), row.pw_salt)).hash, row.pw_hash)) throw new HttpError(401, 'wrong_password');
    const nx = String(b.next || ''); if (nx.length < 8 || nx.length > 128) throw new HttpError(400, 'weak_password');
    const { hash, salt } = await hashPassword(nx);
    const keep = await sha256(cookie(req, 'nl_session') || '');
    await env.DB.batch([
      env.DB.prepare('UPDATE users SET pw_hash = ?, pw_salt = ? WHERE id = ?').bind(hash, salt, u.id),
      env.DB.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?').bind(u.id, keep), // sign out other devices
    ]);
    return json(req, { ok: true });
  }
  if (p === '/me/export' && m === 'GET') {
    const u = await requireUser(req, env);
    const ledger = (await env.DB.prepare('SELECT amount, reason, game, created_at FROM coin_ledger WHERE user_id = ? ORDER BY id').bind(u.id).all()).results;
    const vouchers = (await env.DB.prepare('SELECT code, percent, cost, status, created_at, expires_at, used_at, used_channel FROM vouchers WHERE user_id = ?').bind(u.id).all()).results;
    return json(req, { exported_at: new Date().toISOString(), account: u, coin_history: ledger, vouchers }, 200, { 'content-disposition': 'attachment; filename="nonla-my-data.json"' });
  }
  if (p === '/me/delete' && m === 'POST') {
    const u = await requireUser(req, env), b = await body(req);
    const row = await env.DB.prepare('SELECT pw_hash, pw_salt FROM users WHERE id = ?').bind(u.id).first();
    if (!safeEqual((await hashPassword(String(b.password || '').slice(0, 128), row.pw_salt)).hash, row.pw_hash)) throw new HttpError(401, 'wrong_password');
    await env.DB.batch([
      env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(u.id),
      env.DB.prepare('DELETE FROM coin_ledger WHERE user_id = ?').bind(u.id),
      env.DB.prepare('DELETE FROM vouchers WHERE user_id = ?').bind(u.id),
      env.DB.prepare('DELETE FROM login_attempts WHERE key = ?').bind('e:' + u.email),
      env.DB.prepare('DELETE FROM users WHERE id = ?').bind(u.id),
    ]);
    return json(req, { ok: true }, 200, { 'Set-Cookie': sessionCookie('', 0) });
  }

  // ---------- Coins ----------
  if (p === '/coins/earn' && m === 'POST') {
    const u = await requireUser(req, env), b = await body(req);
    const game = String(b.game || '');
    if (!GAMES.includes(game)) return json(req, { earned: 0, reason: 'no_coins_for_game', coins: u.coins });
    const level = Math.max(1, Math.min(5, parseInt(b.level, 10) || 1));
    let earned = b.passed === true ? 4 + 2 * level : b.passed === false ? 1 : 2;
    const last = await env.DB.prepare("SELECT created_at FROM coin_ledger WHERE user_id = ? AND reason = 'game' ORDER BY id DESC LIMIT 1").bind(u.id).first();
    if (last && now() - last.created_at < COOLDOWN_SEC * 1000) return json(req, { earned: 0, reason: 'cooldown', coins: u.coins });
    const today = (await env.DB.prepare("SELECT COALESCE(SUM(amount),0) AS s FROM coin_ledger WHERE user_id = ? AND reason = 'game' AND created_at >= ?").bind(u.id, dayStart()).first()).s;
    earned = Math.max(0, Math.min(earned, DAILY_CAP - today));
    if (!earned) return json(req, { earned: 0, reason: 'daily_cap', coins: u.coins });
    await env.DB.batch([
      env.DB.prepare("INSERT INTO coin_ledger (user_id, amount, reason, game, created_at) VALUES (?, ?, 'game', ?, ?)").bind(u.id, earned, game, now()),
      env.DB.prepare('UPDATE users SET coins = coins + ? WHERE id = ?').bind(earned, u.id),
    ]);
    return json(req, { earned, coins: u.coins + earned, dailyLeft: DAILY_CAP - today - earned });
  }

  // ---------- Vouchers ----------
  if (p === '/vouchers/redeem' && m === 'POST') {
    const u = await requireUser(req, env), b = await body(req);
    const tier = TIERS[b.tier]; if (!tier) throw new HttpError(400, 'bad_tier');
    const r = await env.DB.prepare('UPDATE users SET coins = coins - ? WHERE id = ? AND coins >= ?').bind(tier.coins, u.id, tier.coins).run();
    if (!r.meta.changes) throw new HttpError(400, 'not_enough_coins');
    const code = voucherCode(), t0 = now();
    await env.DB.batch([
      env.DB.prepare("INSERT INTO vouchers (code, user_id, percent, cost, status, created_at, expires_at) VALUES (?, ?, ?, ?, 'active', ?, ?)").bind(code, u.id, tier.percent, tier.coins, t0, t0 + VOUCHER_DAYS * 864e5),
      env.DB.prepare("INSERT INTO coin_ledger (user_id, amount, reason, game, created_at) VALUES (?, ?, 'voucher', ?, ?)").bind(u.id, -tier.coins, code, t0),
    ]);
    return json(req, { code, percent: tier.percent, expires_at: t0 + VOUCHER_DAYS * 864e5 });
  }

  // ---------- Staff ----------
  if (p === '/admin/voucher/check' && m === 'POST') {
    requireAdmin(req, env); const b = await body(req);
    const v = await env.DB.prepare('SELECT v.code, v.percent, v.status, v.expires_at, v.used_at, v.used_channel, u.name FROM vouchers v JOIN users u ON u.id = v.user_id WHERE v.code = ?').bind(clean(b.code, 20).toUpperCase()).first();
    if (!v) throw new HttpError(404, 'voucher_not_found');
    if (v.status === 'active' && v.expires_at < now()) v.status = 'expired';
    v.name = (v.name || '').split(' ')[0]; // first name only – data minimisation
    return json(req, v);
  }
  if (p === '/admin/voucher/use' && m === 'POST') {
    requireAdmin(req, env); const b = await body(req);
    const code = clean(b.code, 20).toUpperCase(), ch = b.channel === 'online' ? 'online' : 'store';
    const r = await env.DB.prepare("UPDATE vouchers SET status = 'used', used_at = ?, used_channel = ?, used_note = ? WHERE code = ? AND status = 'active' AND expires_at >= ?").bind(now(), ch, clean(b.note, 120), code, now()).run();
    if (!r.meta.changes) throw new HttpError(400, 'voucher_not_usable');
    return json(req, { ok: true });
  }
  throw new HttpError(404, 'not_found');
}

export default {
  async fetch(req, env) {
    try { return await route(req, env); }
    catch (e) {
      if (e instanceof HttpError) return json(req, { error: e.code }, e.status);
      console.error(e);
      return json(req, { error: 'server_error' }, 500);
    }
  }
};
