-- Nón Lá – D1 database schema. Paste into Cloudflare → D1 → your database → Console → Execute.
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  phone TEXT,
  pw_hash TEXT NOT NULL,
  pw_salt TEXT NOT NULL,
  marketing INTEGER NOT NULL DEFAULT 0,
  coins INTEGER NOT NULL DEFAULT 0 CHECK (coins >= 0),
  created_at INTEGER NOT NULL,
  terms_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE TABLE IF NOT EXISTS coin_ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  amount INTEGER NOT NULL,
  reason TEXT NOT NULL,
  game TEXT,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ledger_user ON coin_ledger(user_id, created_at);
CREATE TABLE IF NOT EXISTS vouchers (
  code TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  percent INTEGER NOT NULL,
  cost INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  used_at INTEGER,
  used_channel TEXT,
  used_note TEXT
);
CREATE INDEX IF NOT EXISTS idx_vouchers_user ON vouchers(user_id);
CREATE TABLE IF NOT EXISTS login_attempts (
  key TEXT NOT NULL,
  at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_attempts ON login_attempts(key, at);
